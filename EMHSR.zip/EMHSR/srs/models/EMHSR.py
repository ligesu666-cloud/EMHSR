"""EMHSR: Edge-Mask based Heterogeneous Social-aware Session Recommendation
（面向多类别敏感链接保护的边掩码异构社交感知会话推荐方法）

这是论文提出的模型。其推荐骨干复用 SERec 框架中的
    * SEFrame  —— 异构图注意力聚合（对应论文 §4.3 的 HGAN，在元路径
                 user-followedby-user / user-clicks-item / item-transitsto-item
                 上做多层异构图注意力，得到全局节点嵌入）；
    * SERecLayer (PSE) —— 个性化会话编码层（论文 §4.4 的会话级个性化嵌入）；
    * fc_sr  —— 用户感知 MLP，输出下一项目打分。
的差异在于：EMHSR 训练所依赖的异构图来自 **经过差分隐私边掩码保护的
关系矩阵**（user-user 社交边用随机响应，user-item 交互用 Laplace 机制，
item-item 共现用计数聚合，三者均满足 ε-LDP，见论文 §4.2 与
``Utils/Preprocess/edge_mask.py``）。隐私预算 ε 通过数据切分
``datasets/<name>/dp_<epsilon>/`` 传入。

因此，EMHSR 的代码实体 = 在 DP 边掩码图上运行的社交感知会话推荐模型
（即 train.py 中 ``edge_style='sampling'`` 且 ``exp_style='dp'`` 时加载的模型）。
本类在语义上把“带噪声的模型”显式命名为 EMHSR，方便与论文一一对应。
"""
import torch as th
from torch import nn
import dgl

from srs.layers.seframe import SEFrame
from srs.layers.serec import SERecLayer
from Utils.DataLoader.collate import CollateFnGNN
from Utils.Dict import Dict
from Utils.DataLoader.prepare_batch import prepare_batch_factory_recursive
from Utils.DataLoader.transform import seq_to_weighted_graph


class EMHSR(SEFrame):
    def __init__(
        self,
        num_users,
        num_items,
        embedding_dim,
        knowledge_graph,
        num_layers,
        num_heads=1,
        use_hgan=True,
        use_pse=True,
        relu=False,
        batch_norm=True,
        feat_drop=0.0,
        **kwargs
    ):
        super().__init__(
            num_users,
            num_items,
            embedding_dim,
            knowledge_graph,
            num_layers,
            num_heads=num_heads,
            use_hgan=use_hgan,
            batch_norm=batch_norm,
            feat_drop=feat_drop,
        )
        # 论文式 (8) 的投影：item / user 特征映射到同维
        self.fc_i = nn.Linear(embedding_dim, embedding_dim, bias=False)
        self.fc_u = nn.Linear(embedding_dim, embedding_dim, bias=False)
        # 个性化会话编码层 PSE（论文 §4.4）；消融时可关闭
        self.use_pse = use_pse
        if use_pse:
            self.PSE_layer = SERecLayer(
                embedding_dim,
                num_steps=1,
                batch_norm=batch_norm,
                feat_drop=feat_drop,
                relu=relu,
            )
        else:
            self.PSE_layer = None
        # 最终嵌入 [s^E_{u_i} || Emb_{u_i}] -> MLP -> 下一项目打分（论文式 (9)-(10)）
        input_dim = 3 * embedding_dim
        self.batch_norm = nn.BatchNorm1d(input_dim) if batch_norm else None
        self.fc_sr = nn.Linear(input_dim, embedding_dim, bias=False)

    def forward(self, inputs, extra_inputs=None):
        # 阶段二：异构图注意力得到全局节点嵌入 Z（论文式 (5)-(7)）
        KG_embeddings = super().forward(extra_inputs)

        uid, g = inputs
        iid = g.ndata['iid']  # (num_nodes,)
        feat_i = KG_embeddings['item'][iid]
        feat_u = KG_embeddings['user'][uid]
        feat = self.fc_i(feat_i) + dgl.broadcast_nodes(g, self.fc_u(feat_u))
        # 个性化会话嵌入 s^E_{u_i}
        if self.use_pse:
            feat_i = self.PSE_layer(g, feat, feat_u)
        else:
            # 消融 w/o PSE：用「序列末项物品嵌入 || 用户嵌入」作为会话表征，
            # 保持与 PSE 路径一致的 batch 对齐（按 last 节点取每会话末项）。
            last_nodes = g.filter_nodes(lambda nodes: nodes.data['last'] == 1)
            feat_i = th.cat([feat[last_nodes], feat_u], dim=1)
        sr = th.cat([feat_i, feat_u], dim=1)
        if self.batch_norm is not None:
            sr = self.batch_norm(sr)
        # 与用户嵌入拼接后经 MLP 得到下一会话嵌入，再点积物品嵌入矩阵得到打分
        logits = self.fc_sr(sr) @ self.item_embedding(self.item_indices).t()
        return logits


seq_to_graph_fns = [seq_to_weighted_graph]

config = Dict({
    'Model': EMHSR,
    'seq_to_graph_fns': seq_to_graph_fns,
    'CollateFn': CollateFnGNN,
    'prepare_batch_factory': prepare_batch_factory_recursive,
})
