#!/usr/bin/env bash
# 运行 EMHSR（论文提出的、带差分隐私边掩码的模型）
# 默认数据集 gowalla，隐私预算 ε=0.1。可用环境变量覆盖。
set -e
cd "$(dirname "$0")/.."

DATASET=${EMHSR_DATASET:-gowalla}
EPS=${EMHSR_EPS:-0.1}

echo ">>> Training EMHSR on ${DATASET} (dp, epsilon=${EPS})"
EMHSR_EXP=dp EMHSR_EPS=${EPS} EMHSR_DATASET=${DATASET} EMHSR_MODEL=EMHSR \
    python Train/train.py --model EMHSR

echo ">>> Done. Results -> datasets/${DATASET}/result/dp_${EPS}/EMHSR_dp_${EPS}.xlsx"
