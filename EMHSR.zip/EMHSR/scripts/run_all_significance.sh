#!/bin/zsh
# 5 种子显著性检验全量驱动脚本（顺序执行，结果累积写入 results.csv）
# 用法: zsh scripts/run_all_significance.sh [datasets...]
set -u
cd "$(dirname "$0")/.."
export OMP_NUM_THREADS=${OMP_NUM_THREADS:-4}
export MKL_NUM_THREADS=${MKL_NUM_THREADS:-4}
PY=${PY:-/Users/ldd/.workbuddy/binaries/python/envs/dgl39/bin/python}
DATASETS=(${@:-delicious gowalla brightkite})
SEEDS=(42 123 2024 7 99)

for ds in $DATASETS; do
  for model_mode in "EMHSR:dp" "SERec:non_dp"; do
    model=${model_mode%%:*}
    mode=${model_mode##*:}
    for seed in $SEEDS; do
      echo "=== [$ds] $model ($mode) seed=$seed $(date '+%H:%M:%S') ==="
      $PY scripts/run_significance.py \
        --dataset "$ds" --model "$model" --mode "$mode" \
        --seed "$seed" --epsilon 0.1 --epochs 30 \
        2>&1 | grep -E "SAVED|RESULTS|Error|error|Traceback" || true
    done
  done
done
echo "ALL DONE $(date)"
