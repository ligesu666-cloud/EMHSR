import numpy as np


def randomized_response(adj_matrix, p):
    # 创建响应函数
    def response(x):
        return np.random.choice([x, 1 - x], p=[p, 1 - p])

    # 对邻接矩阵进行随机响应
    noisy_matrix = np.vectorize(response)(adj_matrix)

    return noisy_matrix


# 示例用法
adj_matrix = np.array([[0, 1, 1, 0],
                       [1, 0, 1, 1],
                       [1, 1, 0, 1],
                       [0, 1, 1, 0]])  # 邻接矩阵
p = 0.7  # 响应概率

noisy_matrix = randomized_response(adj_matrix, p)
print("Noisy Matrix:")
print(noisy_matrix)
