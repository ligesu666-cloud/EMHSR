#!/usr/bin/env zsh
# Track B：超参数敏感性（Gowalla，非默认点 7 个）+ 链接窃取攻击（Gowalla，4 个 ε）
# 敏感性跳过默认配置 d=128/L=1/Kh=1（= Full EMHSR，用 significance 数据）。
set -e
cd "$(dirname "$0")/.."
PY=/Users/ldd/.workbuddy/binaries/python/envs/dgl39/bin/python
export OMP_NUM_THREADS=3
export MKL_NUM_THREADS=3
export EMHSR_DATA_ROOT="${EMHSR_DATA_ROOT:-$(pwd)/data712}"

SENS=data712/gowalla/result/sensitivity
ATT=data712/gowalla/result/attack
mkdir -p "$SENS" "$ATT"

for pair in "d 32" "d 64" "d 96" "L 2" "L 3" "Kh 2" "Kh 4"; do
  args=(${=pair})
  echo "===== sensitivity ${args[1]}=${args[2]} (gowalla) $(date) ====="
  "$PY" -B scripts/run_sensitivity.py --dataset gowalla --param "${args[1]}" --value "${args[2]}" \
    >> "$SENS/log.txt" 2>&1
done

echo "===== attack gowalla all-eps $(date) ====="
"$PY" -B scripts/run_attack.py --dataset gowalla --all \
  >> "$ATT/log.txt" 2>&1

echo "ALL TRACK B DONE $(date)"
