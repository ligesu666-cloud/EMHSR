#!/usr/bin/env bash
# 运行全部基线（非 DP 与 DP 两种模式）
#   non_dp : 原始数据（raw/），对应论文表 5.3-5.5 的 non_dp 列
#   dp      : 差分隐私边掩码数据（dp_<epsilon>/），对应 dp 列
# EMHSR 自身的运行见 run_emhsr.sh。
set -e
cd "$(dirname "$0")/.."

DATASET=${EMHSR_DATASET:-gowalla}
EPS=${EMHSR_EPS:-0.1}

echo ">>> [1/2] non_dp baselines on ${DATASET}"
EMHSR_EXP=non_dp EMHSR_DATASET=${DATASET} python Train/train.py

echo ">>> [2/2] dp baselines on ${DATASET} (epsilon=${EPS})"
EMHSR_EXP=dp EMHSR_EPS=${EPS} EMHSR_DATASET=${DATASET} python Train/train.py

echo ">>> Done. Results -> datasets/${DATASET}/result/{non_dp,dp_${EPS}}/"
