#!/usr/bin/env bash
# 复现投稿所用 dp_<epsilon> 数据（legacy Laplace 版本，见 Utils/Preprocess/dp_sampling.py）。
# 若想使用论文 §4.2 严格对齐的三种机制，请改用 scripts/generate_dp_datasets.py。
set -e
cd "$(dirname "$0")/.."

python Utils/Preprocess/dp_sampling.py
echo ">>> Done. Generated datasets/<name>/dp_<epsilon>/{edges,train,valid,test}.txt"
