"""为显著性检验实验准备 7:1:2 重划分数据与 DP(ε=0.1) 扰动数据。

流程（对每个数据集）：
  1. 合并 raw/ 的 train/valid/test 全部会话；
  2. 按用户内 sessionId（时间）顺序，划分 70% / 10% / 20%；
  3. 写入新数据根 ``data712/datasets/<ds>/raw/``（社交边与 stats 原样复制）；
  4. 按 EMHSR 的差分隐私流水线生成 ``data712/datasets/<ds>/dp_0.1/``：
     * 会话–项目交互 (UI)：对每个非零交互元素加 Laplace(0, Δ/ε) 噪声
       后以 0 为阈值保留（与原 dp_sampling.py 的 NoiseAdjMatrix 完全一致，
       敏感度 Δ=1，全量扰动即采样率 q=1）；
     * 社交边 (UU)：同上（与原流水线一致）。
  全程使用固定种子的 RandomState，保证可复现。

用法：
    python scripts/prepare_712_experiments.py [--datasets gowalla delicious brightkite]
"""
import os
import sys
import argparse

import numpy as np
import pandas as pd

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, REPO)

ORIG_ROOT = os.environ.get(
    'EMHSR_ORIG_ROOT',
    '/Users/ldd/Desktop/EMHSR_NC/DPHSSR_extract/DPHSSR/datasets',
)
NEW_ROOT = os.path.join(REPO, 'data712')
EPSILON = 0.1
SENSITIVITY = 1.0
RNG_SEED = 2026


def resplit_712(ds):
    """合并原始 train/valid/test，按用户内时间顺序重划 7:1:2。"""
    frames = []
    for part in ['train', 'valid', 'test']:
        df = pd.read_csv(f'{ORIG_ROOT}/{ds}/raw/{part}.txt', sep='\t')
        frames.append(df)
    alldf = pd.concat(frames, ignore_index=True)

    tr, va, te = [], [], []
    for _, g in alldf.groupby('userId'):
        g = g.sort_values('sessionId')
        n = len(g)
        n_tr = max(1, int(np.floor(n * 0.7)))
        n_va = int(np.floor(n * 0.1))
        tr.append(g.iloc[:n_tr])
        va.append(g.iloc[n_tr:n_tr + n_va])
        te.append(g.iloc[n_tr + n_va:])

    out_dir = f'{NEW_ROOT}/{ds}/raw'
    os.makedirs(out_dir, exist_ok=True)
    for name, parts in [('train', tr), ('valid', va), ('test', te)]:
        out = pd.concat(parts, ignore_index=True)
        out.to_csv(f'{out_dir}/{name}.txt', sep='\t', index=False)
    # 社交边与 stats 原样复制
    for f in ['edges.txt', 'stats.txt']:
        src = f'{ORIG_ROOT}/{ds}/raw/{f}'
        if os.path.exists(src):
            with open(src, 'rb') as fh:
                data = fh.read()
            with open(f'{out_dir}/{f}', 'wb') as fh:
                fh.write(data)

    n_all = sum(len(x) for x in tr) + sum(len(x) for x in va) + sum(len(x) for x in te)
    print(f'[{ds}] 7:1:2 划分完成: train={sum(len(x) for x in tr)} '
          f'valid={sum(len(x) for x in va)} test={sum(len(x) for x in te)} '
          f'(total={n_all})')


def _perturb_pairs(pairs, epsilon, rng):
    """对非零元素 (值恒为 1) 施加 Laplace(0, Δ/ε) 噪声并以 0 为阈值保留。

    与原 dp_sampling.NoiseAdjMatrix 逐元素行为一致。
    """
    if len(pairs) == 0:
        return pairs
    noise = rng.laplace(0.0, SENSITIVITY / epsilon, size=len(pairs))
    keep = (1.0 + noise) > 0
    return pairs[keep]


def dp_perturb(ds, epsilon=EPSILON):
    """生成 dp_<epsilon> 数据目录（会话 + 社交边），复刻原流水线。"""
    rng = np.random.RandomState(RNG_SEED)
    src_dir = f'{NEW_ROOT}/{ds}/raw'
    out_dir = f'{NEW_ROOT}/{ds}/dp_{epsilon}'
    os.makedirs(out_dir, exist_ok=True)

    # ---- 会话–项目交互 (UI) ----
    for part in ['train', 'valid', 'test']:
        df = pd.read_csv(f'{src_dir}/{part}.txt', sep='\t',
                         dtype={'items': str})
        ex = df.assign(it=df['items'].astype(str).str.split(',')).explode('it')
        ex['it'] = ex['it'].astype(int)
        pairs = ex[['sessionId', 'it']].drop_duplicates().values
        kept = _perturb_pairs(pairs, epsilon, rng)
        kept_map = {}
        for s, i in kept:
            kept_map.setdefault(int(s), []).append(int(i))
        # 与原 Matrix2DF(col_style='mul') 一致：
        # 有保留项目的会话用保留集合，否则保留原始 items
        new_items = []
        for _, row in df.iterrows():
            sid = int(row['sessionId'])
            if sid in kept_map:
                new_items.append(','.join(map(str, sorted(set(kept_map[sid])))))
            else:
                new_items.append(str(row['items']))
        out = pd.DataFrame({
            'sessionId': df['sessionId'].values,
            'userId': df['userId'].values,
            'items': new_items,
        })
        out.to_csv(f'{out_dir}/{part}.txt', sep='\t', index=False)
        n_keep = len(kept)
        print(f'[{ds}] dp_{epsilon} {part}: {len(pairs)} 交互 -> 保留 {n_keep} '
              f'({n_keep / max(len(pairs), 1) * 100:.1f}%)')

    # ---- 社交边 (UU) ----
    edges = pd.read_csv(f'{src_dir}/edges.txt', sep='\t')
    pairs = edges[['follower', 'followee']].drop_duplicates().values
    kept = _perturb_pairs(pairs, epsilon, rng)
    out = pd.DataFrame(kept, columns=['follower', 'followee'])
    out.to_csv(f'{out_dir}/edges.txt', sep='\t', index=False)
    print(f'[{ds}] dp_{epsilon} edges: {len(pairs)} -> 保留 {len(kept)} '
          f'({len(kept) / max(len(pairs), 1) * 100:.1f}%)')

    # read_dataset 需要 stats.txt，从 raw 复制
    with open(f'{src_dir}/stats.txt', 'rb') as fh:
        data = fh.read()
    with open(f'{out_dir}/stats.txt', 'wb') as fh:
        fh.write(data)


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--datasets', nargs='+',
                    default=['gowalla', 'delicious', 'brightkite'])
    a = ap.parse_args()
    for ds in a.datasets:
        resplit_712(ds)
        dp_perturb(ds)
    print('全部数据准备完成 ->', NEW_ROOT)
