"""运行 EMHSR 超参数敏感性实验（论文 §补充实验·超参数敏感性 / 表 tab:sensitivity）。

在 7:1:2 划分、ε=0.1 下，对三项超参各做一维网格搜索（其余取默认
embedding_dim=128, num_layers=1, num_heads=1），报告 HR@20：
  * d  ∈ {32, 64, 96, 128}
  * L  ∈ {1, 2, 3}
  * Kh ∈ {1, 2, 4}
每数据集 10 个 run（4+3+3），三数据集共 30 个 run。

结果写入 data712/<ds>/result/sensitivity/results.csv（列：dataset,param,value,HR@20）。

用法:
  python scripts/run_sensitivity.py --dataset gowalla --param d --value 32
  python scripts/run_sensitivity.py --dataset gowalla --all
"""
import os
import sys
import csv
import random
import argparse

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, REPO)
os.environ.setdefault('EMHSR_DATA_ROOT', os.path.join(REPO, 'data712'))

D_DEFAULT, L_DEFAULT, KH_DEFAULT = 128, 1, 1
SWEEPS = {
    'd': [32, 64, 96, 128],
    'L': [1, 2, 3],
    'Kh': [1, 2, 4],
}


def set_seed(seed):
    import numpy as np
    import torch
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def run_one(dataset, param, value, epsilon=0.1, seed=42, epochs=30):
    set_seed(seed)
    import Train.train as T
    from Train.ParserTrain import TrainParser
    T.exp_style = 'dp'

    _argv = sys.argv
    sys.argv = [_argv[0]]
    try:
        p = TrainParser()
    finally:
        sys.argv = _argv
    p.epsilon = epsilon
    p.epochs = epochs
    p.embedding_dim = D_DEFAULT
    p.num_layers = L_DEFAULT
    p.num_heads = KH_DEFAULT
    if param == 'd':
        p.embedding_dim = value
    elif param == 'L':
        p.num_layers = value
    elif param == 'Kh':
        p.num_heads = value

    args, tl, vl, tel = T.TrainRun(p, dataset, 'EMHSR', 'sampling').GetLoader()
    args.Ks = [20]
    runner = T.TrainRunner(tl, vl, tel, **args)
    results, _, _ = runner.train(args.epochs, log_interval=args.log_interval)
    return results.get('HR@20', 0.0) * 100


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dataset', required=True,
                    choices=['gowalla', 'delicious', 'brightkite'])
    ap.add_argument('--param', default=None, choices=['d', 'L', 'Kh'])
    ap.add_argument('--value', type=int, default=None)
    ap.add_argument('--all', action='store_true', help='运行该数据集的全部 10 个 run')
    ap.add_argument('--epsilon', type=float, default=0.1)
    ap.add_argument('--seed', type=int, default=42)
    ap.add_argument('--epochs', type=int, default=30)
    a = ap.parse_args()

    out = os.path.join(
        os.environ['EMHSR_DATA_ROOT'], a.dataset, 'result',
        'sensitivity', 'results.csv')
    os.makedirs(os.path.dirname(out), exist_ok=True)

    jobs = []
    if a.all:
        for param, vals in SWEEPS.items():
            for v in vals:
                jobs.append((param, v))
    else:
        if a.param is None or a.value is None:
            ap.error('--param 与 --value 需同时提供，或使用 --all')
        jobs.append((a.param, a.value))

    for param, value in jobs:
        print(f'=== {a.dataset} {param}={value} ===', flush=True)
        hr = run_one(a.dataset, param, value, a.epsilon, a.seed, a.epochs)
        with open(out, 'a', newline='') as f:
            w = csv.writer(f)
            w.writerow([a.dataset, param, value, round(hr, 4)])
        print(f'RESULT {param}={value}: HR@20={hr:.4f}')


if __name__ == '__main__':
    main()
