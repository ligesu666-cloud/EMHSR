"""链接窃取攻击实证评估（论文 §补充实验·攻击实证评估 / 表 tab:attack）。

在 ε∈{0.01, 0.1, 1, 10} 训练 EMHSR（7:1:2 划分），取出知识图谱的**用户嵌入**
（相当于已发布的受保护图表征），由攻击者据此恢复真实敏感好友边 E_UU：
  * 真实 E_UU 取原始社交图 raw/edges.txt（未加噪）；
  * 攻击者在用户嵌入上做 cosine 相似度排序，评估
      - AUC：所有 (好友对, 非好友对) 的排序一致性；
      - HR@10：每个目标用户其真实好友是否进入相似度 Top-10。
随 ε 减小，嵌入噪声增大，AUC 与 HR@10 应单调下降至随机猜测
（AUC→0.5，HR@10→|E_UU|/n，本脚本在采样用户子集上估计）。

结果写入 data712/<ds>/result/attack/results.csv（列：dataset,epsilon,AUC,HR@10）。

用法:
  python scripts/run_attack.py --dataset gowalla --epsilon 0.1
  python scripts/run_attack.py --dataset gowalla --all
"""
import os
import sys
import csv
import random
import argparse

import numpy as np

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, REPO)
os.environ.setdefault('EMHSR_DATA_ROOT', os.path.join(REPO, 'data712'))

EPSILONS = [0.01, 0.1, 1, 10]
N_SAMPLE = 2000  # 攻击评估的用户采样规模（兼顾算力与统计意义）


def set_seed(seed):
    import torch
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def load_true_adj(dataset, n_sample=N_SAMPLE, seed=0):
    """返回采样用户子集上的真实 UU 邻接（0/1 方阵）。"""
    rng = np.random.RandomState(seed)
    root = os.environ['EMHSR_DATA_ROOT']
    import pandas as pd
    edges = pd.read_csv(
        os.path.join(root, dataset, 'raw', 'edges.txt'), sep='\t')
    edges = edges[['follower', 'followee']].to_numpy(dtype=int)
    users = np.unique(edges)
    if len(users) > n_sample:
        users = rng.choice(users, n_sample, replace=False)
    uid2i = {u: i for i, u in enumerate(users)}
    n = len(users)
    adj = np.zeros((n, n), dtype=np.int8)
    for u, v in edges:
        if u in uid2i and v in uid2i:
            adj[uid2i[u], uid2i[v]] = 1
            adj[uid2i[v], uid2i[u]] = 1
    return adj, users


def evaluate_attack(user_emb, adj):
    """user_emb: (n, d) numpy；adj: (n,n) 0/1。返回 (AUC, HR@10)。"""
    n = user_emb.shape[0]
    # 余弦相似度矩阵
    norm = user_emb / (np.linalg.norm(user_emb, axis=1, keepdims=True) + 1e-12)
    sim = norm @ norm.T
    np.fill_diagonal(sim, -np.inf)

    # AUC：所有无序对
    iu, ju = np.triu_indices(n, k=1)
    labels = adj[iu, ju].astype(int)
    scores = sim[iu, ju]
    order = scores.argsort()
    ranks = np.empty_like(order, dtype=float)
    ranks[order] = np.arange(len(order))
    # 正样本排名和
    n_pos = labels.sum()
    n_neg = len(labels) - n_pos
    if n_pos == 0 or n_neg == 0:
        auc = float('nan')
    else:
        auc = (ranks[labels == 1].sum() - n_pos * (n_pos + 1) / 2) / (n_pos * n_neg)

    # HR@10：每个目标用户，真实好友是否进 Top-10
    topk = min(10, n - 1)
    hits = 0
    targets = 0
    for i in range(n):
        friends = np.where(adj[i] == 1)[0]
        if len(friends) == 0:
            continue
        targets += 1
        top = np.argpartition(-sim[i], topk)[:topk]
        if np.any(adj[i][top] == 1):
            hits += 1
    hr10 = hits / targets if targets else float('nan')
    return float(auc), float(hr10)


def train_and_attack(dataset, epsilon, seed=42, epochs=30, n_sample=N_SAMPLE):
    set_seed(seed)
    import torch
    import Train.train as T
    from Train.ParserTrain import TrainParser
    T.exp_style = 'dp'

    _argv = sys.argv
    sys.argv = [_argv[0]]
    try:
        p = TrainParser()
    finally:
        sys.argv = _argv
    p.epsilon = epsilon
    p.epochs = epochs

    args, tl, vl, tel = T.TrainRun(p, dataset, 'EMHSR', 'sampling').GetLoader()
    runner = T.TrainRunner(tl, vl, tel, **args)
    runner.train(args.epochs, log_interval=args.log_interval)

    # 取出受保护图的用户嵌入
    args.model.eval()
    with torch.no_grad():
        args.model.precompute_KG_embeddings()
        emb = args.model.KG_embeddings['user'].detach().cpu().numpy()

    adj, users = load_true_adj(dataset, n_sample)
    # 仅保留在采样子集内的用户
    emb_sub = emb[users]
    auc, hr10 = evaluate_attack(emb_sub, adj)
    return auc, hr10


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dataset', required=True,
                    choices=['gowalla', 'delicious', 'brightkite'])
    ap.add_argument('--epsilon', type=float, default=0.1, choices=EPSILONS)
    ap.add_argument('--all', action='store_true')
    ap.add_argument('--seed', type=int, default=42)
    ap.add_argument('--epochs', type=int, default=30)
    a = ap.parse_args()

    out = os.path.join(
        os.environ['EMHSR_DATA_ROOT'], a.dataset, 'result',
        'attack', 'results.csv')
    os.makedirs(os.path.dirname(out), exist_ok=True)

    epss = EPSILONS if a.all else [a.epsilon]
    for eps in epss:
        print(f'=== attack {a.dataset} eps={eps} ===', flush=True)
        auc, hr10 = train_and_attack(a.dataset, eps, a.seed, a.epochs)
        with open(out, 'a', newline='') as f:
            w = csv.writer(f)
            w.writerow([a.dataset, eps, round(auc, 4), round(hr10, 4)])
        print(f'RESULT eps={eps}: AUC={auc:.4f} HR@10={hr10:.4f}')


if __name__ == '__main__':
    main()
