"""运行单次（数据集 × 模型 × 模式 × 种子）实验，用于 5 种子显著性检验。

  * EMHSR（论文模型）: --model EMHSR --mode dp  --epsilon 0.1
    加载 data712/datasets/<ds>/dp_0.1/ 的加噪会话与社交边（边掩码图）。
  * SERec（最强基线）: --model SERec --mode non_dp
    加载 data712/datasets/<ds>/raw/ 的原始数据。

结果（在验证集上最优 epoch 对应的测试集 HR/MRR/NDCG@10/20）
追加写入 data712/datasets/<ds>/result/significance/results.csv。

用法示例：
    python scripts/run_significance.py --dataset delicious --model EMHSR --mode dp --seed 42
"""
import os
import sys
import csv
import random
import argparse

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, REPO)

# 数据根指向 7:1:2 重划分目录（必须在 import 训练模块前设置）
os.environ.setdefault('EMHSR_DATA_ROOT', os.path.join(REPO, 'data712'))


def set_seed(seed):
    import numpy as np
    import torch
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dataset', required=True,
                    choices=['gowalla', 'delicious', 'brightkite'])
    ap.add_argument('--model', default='EMHSR')
    ap.add_argument('--mode', default='dp', choices=['dp', 'non_dp'])
    ap.add_argument('--seed', type=int, default=42)
    ap.add_argument('--epsilon', type=float, default=0.1)
    ap.add_argument('--epochs', type=int, default=30)
    ap.add_argument('--out', default=None, help='结果 CSV 路径')
    a = ap.parse_args()

    set_seed(a.seed)

    import Train.train as T
    from Train.ParserTrain import TrainParser

    # 修复 train.GetLoader 对模块级全局 exp_style 的引用
    T.exp_style = a.mode

    # TrainParser() 无参会解析 sys.argv，与脚本自身参数冲突，先清空
    _argv = sys.argv
    sys.argv = [_argv[0]]
    try:
        p = TrainParser()
    finally:
        sys.argv = _argv
    p.epsilon = a.epsilon
    p.epochs = a.epochs
    # 训练批量 / 学习率 / 维度等均沿用 ParserTrain 默认值（与原论文实验一致）

    edges_style = 'sampling' if (a.mode == 'dp' and a.model == 'EMHSR') else 'edges'
    args, train_loader, valid_loader, test_loader = T.TrainRun(
        p, a.dataset, a.model, edges_style).GetLoader()
    runner = T.TrainRunner(train_loader, valid_loader, test_loader, **args)
    results, final_result, batch_time = runner.train(
        args.epochs, log_interval=args.log_interval)

    out = a.out or os.path.join(
        os.environ['EMHSR_DATA_ROOT'], a.dataset, 'result', 'significance',
        'results.csv')
    os.makedirs(os.path.dirname(out), exist_ok=True)
    header = ['dataset', 'model', 'mode', 'epsilon', 'seed'] + sorted(results)
    exists = os.path.exists(out)
    with open(out, 'a', newline='') as f:
        w = csv.writer(f)
        if not exists:
            w.writerow(header)
        w.writerow([a.dataset, a.model, a.mode, a.epsilon, a.seed]
                   + [results[k] for k in sorted(results)])
    print('SAVED ->', out)
    print('RESULTS:', {k: round(v * 100, 4) for k, v in results.items()})


if __name__ == '__main__':
    main()
