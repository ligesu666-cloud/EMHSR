"""对 5 种子结果做均值±标准差与配对 t 检验（EMHSR vs SERec）。

用法:
    python scripts/analyze_significance.py \
        --results data712/datasets/delicious/result/significance/results.csv
"""
import argparse
import os
import sys

import numpy as np
import pandas as pd
from scipy import stats

METRICS = ['HR@10', 'MRR@10', 'NDCG@10', 'HR@20', 'MRR@20', 'NDCG@20']


def analyze(csv_path, out_dir=None):
    df = pd.read_csv(csv_path)
    out_dir = out_dir or os.path.dirname(csv_path)
    lines = []
    for ds, gds in df.groupby('dataset'):
        emhsr = gds[(gds.model == 'EMHSR') & (gds['mode'] == 'dp')]
        serec = gds[(gds.model == 'SERec') & (gds['mode'] == 'non_dp')]
        # 按种子配对（取两种子集交集）
        seeds = sorted(set(emhsr.seed) & set(serec.seed))
        emhsr = emhsr[emhsr.seed.isin(seeds)].sort_values('seed')
        serec = serec[serec.seed.isin(seeds)].sort_values('seed')
        print(f'\n===== {ds} (n={len(seeds)} seeds: {seeds}) =====')
        lines.append(f'\n===== {ds} (n={len(seeds)}) =====')
        rows = []
        for m in METRICS:
            if m not in emhsr.columns:
                continue
            x = emhsr[m].values * 100  # 百分比口径，与论文表格一致
            y = serec[m].values * 100
            t_stat, p_val = stats.ttest_rel(x, y)
            d = x - y
            # Cohen's d (paired): mean(diff)/std(diff)
            cohens_d = d.mean() / d.std(ddof=1) if d.std(ddof=1) > 0 else float('nan')
            sig = '是' if p_val < 0.05 else '否'
            rows.append([ds, m, x.mean(), x.std(ddof=1), y.mean(), y.std(ddof=1),
                         d.mean(), t_stat, p_val, cohens_d, sig])
            print(f'{m:8s}  EMHSR {x.mean():6.2f}±{x.std(ddof=1):4.2f}  '
                  f'SERec {y.mean():6.2f}±{y.std(ddof=1):4.2f}  '
                  f'Δ={d.mean():+5.2f}pp  t={t_stat:+6.3f}  p={p_val:.4f}  '
                  f"d={cohens_d:+.2f}  显著(α=0.05)={sig}")
        rdf = pd.DataFrame(rows, columns=[
            'dataset', 'metric',
            'EMHSR_mean', 'EMHSR_std', 'SERec_mean', 'SERec_std',
            'delta_mean', 't_stat', 'p_value', 'cohens_d', 'significant_0.05'])
        out = os.path.join(out_dir, f'ttest_{ds}.csv')
        rdf.to_csv(out, index=False, encoding='utf-8-sig')
        print('SAVED ->', out)
        lines.append(rdf.to_string(index=False))
    # 汇总文本
    with open(os.path.join(out_dir, 'significance_report.txt'), 'w',
              encoding='utf-8') as f:
        f.write('\n'.join(lines))
    print('\nSAVED ->', os.path.join(out_dir, 'significance_report.txt'))


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--results', required=True)
    a = ap.parse_args()
    analyze(a.results)
