#!/usr/bin/env zsh
# 运行三数据集的超参数敏感性网格（论文 tab:sensitivity），每数据集 10 个 run。
set -e
cd "$(dirname "$0")/.."
export OMP_NUM_THREADS=2
export MKL_NUM_THREADS=2
export EMHSR_DATA_ROOT="${EMHSR_DATA_ROOT:-$(pwd)/data712}"

PY=/Users/ldd/.workbuddy/binaries/python/envs/dgl39/bin/python
for DS in gowalla delicious brightkite; do
  mkdir -p "data712/$DS/result/sensitivity"
  echo "===== sensitivity $DS ====="
  "$PY" scripts/run_sensitivity.py --dataset "$DS" --all \
    >> "data712/$DS/result/sensitivity/log.txt" 2>&1
done
echo "ALL SENSITIVITY DONE $(date)"
