#!/usr/bin/env zsh
# 运行链接窃取攻击实证（论文 tab:attack），3 数据集 × ε∈{0.01,0.1,1,10}。
set -e
cd "$(dirname "$0")/.."
PY=/Users/ldd/.workbuddy/binaries/python/envs/dgl39/bin/python
export OMP_NUM_THREADS=2
export MKL_NUM_THREADS=2
export EMHSR_DATA_ROOT="${EMHSR_DATA_ROOT:-$(pwd)/data712}"

for DS in gowalla delicious brightkite; do
  mkdir -p "data712/$DS/result/attack"
  echo "===== attack $DS ====="
  "$PY" scripts/run_attack.py --dataset "$DS" --all \
    >> "data712/$DS/result/attack/log.txt" 2>&1
done
echo "ALL ATTACK DONE $(date)"
