#!/usr/bin/env zsh
# 运行 Gowalla 上 5 个消融变体（论文 tab:ablation）。
# 用法: zsh scripts/run_all_ablation.sh [dataset]
DATASET=${1:-gowalla}
set -e
cd "$(dirname "$0")/.."
PY=/Users/ldd/.workbuddy/binaries/python/envs/dgl39/bin/python
export OMP_NUM_THREADS=2
export MKL_NUM_THREADS=2
export EMHSR_DATA_ROOT="${EMHSR_DATA_ROOT:-$(pwd)/data712}"

mkdir -p "data712/$DATASET/result/ablation"
for V in wo_uu wo_ui wo_pp wo_hgan wo_pse; do
  echo "===== ablation $V ($DATASET) ====="
  "$PY" scripts/run_ablation.py --dataset "$DATASET" --variant "$V" \
    >> "data712/$DATASET/result/ablation/log.txt" 2>&1
done
echo "ALL ABLATION DONE $(date)"
