"""运行 EMHSR 的模块消融实验（论文 §补充实验·消融实验 / 表 tab:ablation）。

在 Gowalla、ε=0.1、K=20 下，依次运行 5 个 w/o 变体（每个变体固定种子 42，
与 Full EMHSR 的 71.5216/41.6492 同源），将 HR@20、NDCG@20 写入
data712/<ds>/result/ablation/results.csv。

变体定义（与论文表一致，操作化定义见论文脚注）：
  * wo_uu   : UU 边不施加随机响应（原始社交边），数据变体 dp_0.1_wo_uu
  * wo_ui   : UI 边不施加 Laplace（原始会话），数据变体 dp_0.1_wo_ui
  * wo_pp   : 知识图谱去除 item–item（PP）转移边（use_pp=False）
  * wo_hgan : 以无注意力均值聚合替换 HGAN（use_hgan=False）
  * wo_pse  : 关闭个性化会话编码层 PSE（use_pse=False）
（w/o Edge Mask = SERec 骨干、Full EMHSR 为已知数值，不在此重跑。）

用法:
  python scripts/run_ablation.py --dataset gowalla --variant wo_uu
  python scripts/run_ablation.py --dataset gowalla --variant all
"""
import os
import sys
import csv
import random
import argparse

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, REPO)
os.environ.setdefault('EMHSR_DATA_ROOT', os.path.join(REPO, 'data712'))

# 数据变体需要先在 data712 下生成（仅 wo_uu / wo_ui 需要）
from Utils.Preprocess.generate_dp_datasets import generate_one


def set_seed(seed):
    import numpy as np
    import torch
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)


def ensure_dp_variant(dataset, epsilon, ablate):
    if ablate is None:
        return
    generate_one(dataset, epsilon, ablate)


def run_variant(dataset, variant, epsilon=0.1, seed=42, epochs=30):
    # 数据变体映射
    ablate_map = {'wo_uu': 'uu', 'wo_ui': 'ui'}
    dp_suffix = ''
    model_flags = {}
    if variant in ablate_map:
        ablate = ablate_map[variant]
        ensure_dp_variant(dataset, epsilon, ablate)
        dp_suffix = f'_{ablate}'
    elif variant == 'wo_pp':
        model_flags['use_pp'] = False
    elif variant == 'wo_hgan':
        model_flags['use_hgan'] = False
    elif variant == 'wo_pse':
        model_flags['use_pse'] = False
    else:
        raise ValueError(variant)

    set_seed(seed)
    import Train.train as T
    from Train.ParserTrain import TrainParser
    T.exp_style = 'dp'

    _argv = sys.argv[:]
    sys.argv = [_argv[0]]
    try:
        p = TrainParser()
    finally:
        sys.argv = _argv
    p.epsilon = epsilon
    p.epochs = epochs
    p.dp_suffix = dp_suffix
    for k, v in model_flags.items():
        setattr(p, k, v)

    edges_style = 'sampling'
    args, tl, vl, tel = T.TrainRun(p, dataset, 'EMHSR', edges_style).GetLoader()
    # 强制 K=20 评测
    args.Ks = [20]
    runner = T.TrainRunner(tl, vl, tel, **args)
    results, _, _ = runner.train(args.epochs, log_interval=args.log_interval)
    return results


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dataset', default='gowalla')
    ap.add_argument('--variant', default='all',
                    choices=['all', 'wo_uu', 'wo_ui', 'wo_pp', 'wo_hgan', 'wo_pse'])
    ap.add_argument('--epsilon', type=float, default=0.1)
    ap.add_argument('--seed', type=int, default=42)
    ap.add_argument('--epochs', type=int, default=30)
    a = ap.parse_args()

    variants = (['wo_uu', 'wo_ui', 'wo_pp', 'wo_hgan', 'wo_pse']
                if a.variant == 'all' else [a.variant])

    out = os.path.join(
        os.environ['EMHSR_DATA_ROOT'], a.dataset, 'result', 'ablation', 'results.csv')
    os.makedirs(os.path.dirname(out), exist_ok=True)

    for v in variants:
        print(f'=== ablation {v} ===', flush=True)
        res = run_variant(a.dataset, v, a.epsilon, a.seed, a.epochs)
        with open(out, 'a', newline='') as f:
            w = csv.writer(f)
            w.writerow([a.dataset, v, a.epsilon,
                        round(res.get('HR@20', 0) * 100, 4),
                        round(res.get('NDCG@20', 0) * 100, 4)])
        print(f'RESULT {v}: HR@20={res.get("HR@20",0)*100:.4f} '
              f'NDCG@20={res.get("NDCG@20",0)*100:.4f}')


if __name__ == '__main__':
    main()
