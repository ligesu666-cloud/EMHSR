#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""表10 隐私保护基线复现实验驱动。

在统一协议（7:1:2 时间划分、ε=0.1、全物品排序 HR@K、seed=42）下
运行 EMHSR/model/ 中的四个基线复现模型，结果写入
data712/<dataset>/result/dp_baselines/results.csv。

用法:
  python scripts/run_dp_baselines.py --dataset gowalla --all
  python scripts/run_dp_baselines.py --dataset delicious --baseline dplcf
"""
import argparse
import csv
import os
import sys
import time

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, REPO)
os.environ.setdefault('EMHSR_DATA_ROOT', os.path.join(REPO, 'data712'))

from model.common import load_data, load_social, set_seed  # noqa: E402

BASELINES = ['dplcf', 'improved_dpcf', 'lpgnn_rec', 'community_ldp']


def run_baseline(name, epsilon, df_train, df_valid, df_test,
                 num_users, num_items, social_edges, seed):
    if name == 'dplcf':
        from model.dplcf import DPLCF
        m = DPLCF(epsilon, num_users, num_items, mode='AP')
        m.fit(df_train)
    elif name == 'improved_dpcf':
        from model.improved_dpcf import ImprovedDPCF
        m = ImprovedDPCF(epsilon, num_users, num_items, seed=seed)
        m.fit(df_train)
    elif name == 'lpgnn_rec':
        from model.lpgnn_rec import LPGNNRec
        m = LPGNNRec(epsilon, num_users, num_items, seed=seed)
        m.fit(df_train, df_valid)
    elif name == 'community_ldp':
        from model.community_ldp import CommunityLDPSocialRec
        m = CommunityLDPSocialRec(epsilon, num_users, num_items, seed=seed)
        m.fit(df_train, social_edges)
    else:
        raise ValueError(name)
    return m.evaluate(df_test, ks=(10, 20))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--dataset', required=True,
                    choices=['gowalla', 'delicious', 'brightkite'])
    ap.add_argument('--epsilon', type=float, default=0.1)
    ap.add_argument('--seed', type=int, default=42)
    ap.add_argument('--baseline', choices=BASELINES + ['all'], default='all')
    a = ap.parse_args()

    set_seed(a.seed)
    df_train, df_valid, df_test, num_users, num_items = load_data(
        os.environ['EMHSR_DATA_ROOT'], a.dataset)
    social_edges = load_social(os.environ['EMHSR_DATA_ROOT'], a.dataset)
    names = BASELINES if a.baseline == 'all' else [a.baseline]

    out = os.path.join(os.environ['EMHSR_DATA_ROOT'], a.dataset, 'result',
                       'dp_baselines', 'results.csv')
    os.makedirs(os.path.dirname(out), exist_ok=True)
    for name in names:
        t0 = time.time()
        print(f'=== {a.dataset} {name} eps={a.epsilon} seed={a.seed} ===',
              flush=True)
        res = run_baseline(name, a.epsilon, df_train, df_valid, df_test,
                           num_users, num_items, social_edges, a.seed)
        with open(out, 'a', newline='') as f:
            w = csv.writer(f)
            w.writerow([a.dataset, name, a.epsilon, a.seed,
                        round(res['HR@10'] * 100, 4),
                        round(res['HR@20'] * 100, 4),
                        round(res['NDCG@20'] * 100, 4),
                        res['num_pairs'], round(time.time() - t0, 1)])
        print(f'RESULT {name}: HR@10={res["HR@10"]*100:.2f} '
              f'HR@20={res["HR@20"]*100:.2f} '
              f'NDCG@20={res["NDCG@20"]*100:.2f} '
              f'pairs={res["num_pairs"]} time={time.time()-t0:.0f}s',
              flush=True)


if __name__ == '__main__':
    main()
