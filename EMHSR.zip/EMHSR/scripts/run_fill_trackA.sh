#!/usr/bin/env zsh
# Track A：消融实验剩余变体（Gowalla, ε=0.1, seed=42, 30 epochs）
# wo_pp 已完成（results.csv 已有条目），此处跑其余 4 个变体。
set -e
cd "$(dirname "$0")/.."
PY=/Users/ldd/.workbuddy/binaries/python/envs/dgl39/bin/python
export OMP_NUM_THREADS=3
export MKL_NUM_THREADS=3
export EMHSR_DATA_ROOT="${EMHSR_DATA_ROOT:-$(pwd)/data712}"

mkdir -p data712/gowalla/result/ablation
for V in wo_uu wo_ui wo_hgan wo_pse; do
  echo "===== ablation $V (gowalla) $(date) ====="
  "$PY" -B scripts/run_ablation.py --dataset gowalla --variant "$V" \
    >> data712/gowalla/result/ablation/log.txt 2>&1
done
echo "ALL TRACK A DONE $(date)"
