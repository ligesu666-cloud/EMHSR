# EMHSR: Edge-Mask based Heterogeneous Social-aware Session Recommendation with Multi-Category Sensitive Link Protection

> **Locally Differentially Private Edge Masking for Heterogeneous Social-Aware Session Recommendation with Multi-Category Sensitive Link Protection**
>
> Gesu Li¹², Fukun Chen³\* &nbsp; (¹ Harbin Normal University; ² Harbin Engineering University; ³ Liaoning Normal University)
>
> Target venue: **Neurocomputing** (Elsevier, SCI Q1 / Top)

EMHSR is a session recommendation method that protects **multi-category sensitive
links** (user–user social ties, user–item interactions, item–item co-occurrences)
with **local differential privacy (LDP)**, and then performs heterogeneous
social-aware recommendation over the *edge-masked* graph. The recommendation
backbone reuses the SERec heterogeneous-graph framework; the contribution is the
**edge-mask protection stage** plus its **rigorous ε-LDP analysis**.

---

## 1. What "EMHSR" means in this codebase

This repository contains the full experimental code. The proposed model
**EMHSR is the *noisy* model**: it is trained on data produced by the
differential-privacy edge-mask stage.

| Concept | Code |
| --- | --- |
| Edge-mask protection (paper §4.2) | `Utils/Preprocess/edge_mask.py` (+ `dp_sampling.py`) |
| Heterogeneous graph + HGAN (paper §4.3) | `srs/layers/seframe.py` (`SEFrame` / `KnowledgeGraphEmbeddingLayer`) |
| Personalized session encoding (paper §4.4) | `srs/layers/serec.py` (`SERecLayer` / `PSE`) |
| **Proposed model EMHSR** (paper §4) | `srs/models/EMHSR.py` (SEFrame + PSE + user-aware MLP) |
| Training / evaluation | `Train/train.py`, `Train/trainModel.py` |
| Baselines (non-DP & DP) | `srs/models/{SRGNN,SSRGNN,SERec,NARM,STAMP,NextItNet,...}.py` |

A model run with `exp_style='dp'` (loads `datasets/<name>/dp_<epsilon>/`) and
`edge_style='sampling'` is exactly the EMHSR model; the same backbones run on
`raw/` data are the (non-DP) baselines.

---

## 2. Multi-category edge-mask protection (paper §4.2)

All three relations are perturbed **element-wise and independently**, so the
joint release still satisfies pure ε-DP and the budget **does not** grow with
the number of users/edges (parallel composition).

| Relation | Mechanism | Privacy |
| --- | --- | --- |
| User–Item (UI) | Laplace `laplace_edge_mask` | ε-LDP (density-ratio ≤ e^ε) |
| Item–Item (PP) | count aggregation `aggregate_item_item_mask` | ε-LDP (post-processing) |
| User–User (UU) | randomized response `randomized_response_mask` | pure ε-LDP, ε = ln(p/(1−p)) |

The rigorous proofs (Laplace density ratio, randomized-response ratio, and the
*n* independent users ⇒ ε-DP result) are in the paper §4.2.

---

## 3. Repository layout

```
EMHSR/
├── Train/
│   ├── ParserTrain.py      # CLI args (--model, --epsilon, --embedding_dim, ...)
│   ├── train.py            # entry point: builds loaders, trains, saves .xlsx
│   └── trainModel.py       # TrainRunner (optimizer, loss, early-stop, metrics)
├── Utils/
│   ├── paths.py            # central data-root (env EMHSR_DATA_ROOT)
│   ├── Dict.py, util.py
│   ├── DataLoader/         # session datasets, DGL graph building, collate
│   └── Preprocess/
│       ├── edge_mask.py          # ★ paper §4.2: 3 LDP mechanisms
│       ├── dp_sampling.py        # legacy Laplace generator (reproduces submission)
│       ├── DatasetProcess.py     # raw checkin -> raw/{train,valid,test,edges}.txt
│       └── utils_processdata.py  # session grouping / filtering helpers
├── srs/
│   ├── layers/             # seframe.py (HGAN), serec.py (PSE), srgnn, narm, stamp, ...
│   └── models/             # EMHSR.py (proposed) + 10 baselines
├── scripts/
│   ├── generate_dp_datasets.py   # ★ paper-aligned DP data generator
│   ├── run_emhsr.sh
│   ├── run_baselines.sh
│   └── run_dp_sampling_legacy.sh
├── Fig.py, summarize.py    # privacy–utility plots & result tables
└── datasets/               # NOT committed (regenerate, see §5)
```

---

## 4. Installation

```bash
conda create -n emhsr python=3.9
conda activate emhsr
pip install torch==1.13.1+cu117 -f https://download.pytorch.org/whl/torch_stable.html
pip install dgl==0.9.1 -f https://data.dgl.ai/wheels/torch-1.13/cu117/repo.html
pip install -r requirements.txt
```

---

## 5. Data preparation

Datasets (Gowalla, Brightkite, Delicious) are public; they are **not** committed
(823 MB). Place the processed `raw/` splits under `datasets/<name>/raw/`:

```
datasets/gowalla/raw/{train.txt, valid.txt, test.txt, edges.txt, stats.txt}
```

`train/valid/test.txt` are tab-separated `userId \t items` (items = comma-joined
item ids); `edges.txt` is `follower \t followee`. If you start from the original
check-in files, run `python Utils/Preprocess/DatasetProcess.py` (edit the
dataset name / paths there) to produce `raw/`.

Then generate the DP edge-masked splits:

```bash
# paper-aligned (recommended): randomized response (UU) + Laplace (UI) + aggregation (PP)
python scripts/generate_dp_datasets.py
# or reproduce the exact submission numbers (legacy Laplace-on-adjacency):
bash scripts/run_dp_sampling_legacy.sh
# optionally override the data root:
EMHSR_DATA_ROOT=/your/data python scripts/generate_dp_datasets.py
```

---

## 6. Training & evaluation

```bash
# EMHSR (proposed, dp, epsilon=0.1) on gowalla
bash scripts/run_emhsr.sh

# all baselines, both non_dp and dp modes
bash scripts/run_baselines.sh

# one model / dataset / epsilon via env vars
EMHSR_EXP=dp EMHSR_EPS=0.1 EMHSR_DATASET=gowalla EMHSR_MODEL=SSRGNN \
    python Train/train.py --model SSRGNN
```

Results are written to `datasets/<name>/result/<exp_style>/<Model>_<exp_style>.xlsx`
(HR@K, MRR@K, NDCG@K for K=10,20). The privacy–utility curves are produced by
`python Fig.py` (reads `datasets/<name>/finalresult/SERec_dp_contrast.xlsx`).

---

## 7. Reproducing the paper's tables

1. Generate DP data (§5).
2. Run every baseline + EMHSR in both `non_dp` and `dp` modes across
   `ε ∈ {0.001, 0.01, 0.1, 1, 10, 100}` (set `EMHSR_EPS` per run).
3. `python summarize.py` → contrast tables under `datasets/<name>/finalresult/`.

EMHSR vs. SSRGNN gains in the paper are averaged relative improvements over the
three datasets × {K=10,20} (HR@10/20, MRR@10/20, NDCG@10/20).

---

## 8. Note on reused code

The heterogeneous-graph recommendation backbone (`srs/`, `Utils/DataLoader/`)
builds on the public **SERec / srs** framework (CRIPAC-DIG/srs). EMHSR's novel
contributions are the edge-mask protection stage, the rigorous ε-LDP analysis
(§4.2), and the EMHSR model definition (`srs/models/EMHSR.py`).

---

## 9. Citation

```bibtex
@article{li2026emhsr,
  title   = {Edge-Mask based Heterogeneous Social-aware Session Recommendation
             with Multi-Category Sensitive Link Protection},
  author  = {Li, Gesu and Chen, Fukun},
  journal = {Neurocomputing},
  year    = {2026}
}
```
