"""汇总各模型 / 各隐私预算下的实验结果，生成对比表。

依赖 `datasets/<name>/result/<exp_style>/*.xlsx`（由 Train/train.py 产出）与
`datasets/<name>/finalresult/`（汇总输出）。所有路径由 `Utils.paths` 统一管理，
可用环境变量 ``EMHSR_DATA_ROOT`` 覆盖数据根目录。

用法:
    python summarize.py
"""
import os
import sys

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from Utils.paths import result_dir, finalresult_dir


def GetMinResutl(exp_style, model_list, dataset_list, result_style, epsilon=0.1):
    if exp_style == 'dp':
        exp_style = f'dp_{epsilon}'
    for dataset_name in dataset_list:
        summarize = dict()
        col_name = ['HR@10', 'MRR@10', 'NDCG@10', 'HR@20', 'MRR@20', 'NDCG@20']
        for i in col_name:
            summarize[i] = {}
            for model_name in model_list:
                df = pd.read_excel(
                    os.path.join(result_dir(dataset_name, exp_style),
                                 f'{model_name}_{exp_style}.xlsx'))
                if result_style == 'min':
                    summarize[i][f'{model_name}'] = min(df[i]) * 100
                elif result_style == 'max':
                    summarize[i][f'{model_name}'] = max(df[i]) * 100

        summarize = pd.DataFrame(summarize)
        save_path = finalresult_dir(dataset_name) + '/'
        if not os.path.exists(save_path):
            os.makedirs(save_path)
        summarize.to_excel(save_path + f'{exp_style}_{result_style}_contrast.xlsx')
    return


model_name = 'SERec'

epsilon_list = [0.001, 0.01, 0.1, 1, 10, 100]
dataset_list = ['gowalla', 'brightkite', 'delicious']
result_style = 'max'
for dataset_name in dataset_list:
    summarize = dict()
    col_name = ['HR@10', 'MRR@10', 'NDCG@10', 'HR@20', 'MRR@20', 'NDCG@20']
    for i in col_name:
        summarize[i] = {}
        for epsilon in epsilon_list:
            exp_style = f'dp_{epsilon}'
            df = pd.read_excel(
                os.path.join(result_dir(dataset_name, exp_style),
                             f'{model_name}_{exp_style}.xlsx'))
            summarize[i][f'{epsilon}'] = max(df[i]) * 100
    summarize = pd.DataFrame(summarize)
    save_path = finalresult_dir(dataset_name) + '/'
    if not os.path.exists(save_path):
        os.makedirs(save_path)
    summarize.to_excel(save_path + f'{model_name}_dp_contrast.xlsx')
