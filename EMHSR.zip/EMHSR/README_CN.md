# EMHSR：面向多类别敏感链接保护的边掩码异构社交感知会话推荐

> **英文题名**：Locally Differentially Private Edge Masking for Heterogeneous
> Social-Aware Session Recommendation with Multi-Category Sensitive Link Protection
>
> 作者：李格苏（哈尔滨师范大学 / 哈尔滨工程大学）、陈福坤（辽宁师范大学，通讯作者）
> 投稿目标：**Neurocomputing**（Elsevier，SCI 一区 / Top）

EMHSR 是一种会话推荐方法：先用**本地化差分隐私（LDP）**保护**多类别敏感链接**
（用户–用户社交关系、用户–项目交互、项目–项目共现），再在**边掩码异构图**上做
异构社交感知推荐。推荐骨干复用 SERec 异构图框架，本文的创新点在于
**边掩码保护阶段**及其**严格 ε-LDP 理论分析**。

---

## 1. 代码中“EMHSR”的含义

本仓库即论文全部实验代码。**EMHSR 就是“带噪声的模型”**：它在差分隐私边掩码
阶段产出的数据上训练。

| 论文概念 | 代码位置 |
| --- | --- |
| 边掩码保护（§4.2） | `Utils/Preprocess/edge_mask.py`（+ `dp_sampling.py`） |
| 异构图 + HGAN（§4.3） | `srs/layers/seframe.py`（`SEFrame` / `KnowledgeGraphEmbeddingLayer`） |
| 个性化会话编码（§4.4） | `srs/layers/serec.py`（`SERecLayer` / `PSE`） |
| **提出的 EMHSR 模型（§4）** | `srs/models/EMHSR.py`（SEFrame + PSE + 用户感知 MLP） |
| 训练 / 评估 | `Train/train.py`、`Train/trainModel.py` |
| 基线（非 DP 与 DP） | `srs/models/{SRGNN,SSRGNN,SERec,NARM,STAMP,NextItNet,...}.py` |

当以 `exp_style='dp'`（加载 `datasets/<name>/dp_<epsilon>/`）且
`edge_style='sampling'` 运行某社交模型时，即为 **EMHSR**；同一骨干在 `raw/` 数据
上运行即为（非 DP）基线。

---

## 2. 多类别边掩码保护（论文 §4.2）

三类关系均**逐元素独立**扰动，因此联合发布仍满足纯 ε-DP，且隐私预算 **不随**
用户/边数放大（并行组合定理）。

| 关系 | 机制 | 隐私性 |
| --- | --- | --- |
| 用户–项目 (UI) | Laplace `laplace_edge_mask` | ε-LDP（密度比 ≤ e^ε） |
| 项目–项目 (PP) | 计数聚合 `aggregate_item_item_mask` | ε-LDP（后处理不变性） |
| 用户–用户 (UU) | 随机响应 `randomized_response_mask` | 纯 ε-LDP，ε = ln(p/(1−p)) |

严格证明（Laplace 密度比、随机响应比值、*n* 个独立用户 ⇒ ε-DP）见论文 §4.2。

---

## 3. 目录结构

```
EMHSR/
├── Train/            # ParserTrain.py(参数) / train.py(入口) / trainModel.py(训练器)
├── Utils/
│   ├── paths.py      # 统一数据根目录（环境变量 EMHSR_DATA_ROOT）
│   ├── DataLoader/   # 会话数据集、DGL 构图、collate
│   └── Preprocess/
│       ├── edge_mask.py          # ★ 论文 §4.2：三种 LDP 机制
│       ├── dp_sampling.py        # legacy Laplace 生成器（复现投稿结果）
│       ├── DatasetProcess.py     # 原始签到 -> raw/{train,valid,test,edges}.txt
│       └── utils_processdata.py  # 会话分组 / 过滤等
├── srs/
│   ├── layers/       # seframe.py(HGAN) / serec.py(PSE) / srgnn / narm / stamp ...
│   └── models/       # EMHSR.py(提出) + 10 个基线
├── scripts/          # generate_dp_datasets.py / run_emhsr.sh / run_baselines.sh
├── Fig.py, summarize.py   # 隐私–效用曲线与结果汇总表
└── datasets/         # 不入库（本地生成，见 §5）
```

---

## 4. 安装

```bash
conda create -n emhsr python=3.9 && conda activate emhsr
pip install torch==1.13.1+cu117 -f https://download.pytorch.org/whl/torch_stable.html
pip install dgl==0.9.1 -f https://data.dgl.ai/wheels/torch-1.13/cu117/repo.html
pip install -r requirements.txt
```

---

## 5. 数据准备

Gowalla / Brightkite / Delicious 为公开数据集，**不随仓库提交**（约 823 MB）。
请将处理好的 `raw/` 切分放在 `datasets/<name>/raw/`：

```
datasets/gowalla/raw/{train.txt, valid.txt, test.txt, edges.txt, stats.txt}
```

其中 `train/valid/test.txt` 为 `userId \t items`（items 为逗号分隔物品 id），
`edges.txt` 为 `follower \t followee`。若从原始签到文件开始，运行
`python Utils/Preprocess/DatasetProcess.py` 生成 `raw/`。

生成 DP 边掩码切分：

```bash
# 论文对齐（推荐）：随机响应(UU) + Laplace(UI) + 聚合(PP)
python scripts/generate_dp_datasets.py
# 复现投稿原始数值（legacy Laplace-on-adjacency）：
bash scripts/run_dp_sampling_legacy.sh
# 可用环境变量覆盖数据根目录：
EMHSR_DATA_ROOT=/your/data python scripts/generate_dp_datasets.py
```

---

## 6. 训练与评估

```bash
bash scripts/run_emhsr.sh                 # EMHSR（dp, ε=0.1）on gowalla
bash scripts/run_baselines.sh             # 全部基线（non_dp + dp）
EMHSR_EXP=dp EMHSR_EPS=0.1 EMHSR_DATASET=gowalla EMHSR_MODEL=SSRGNN \
    python Train/train.py --model SSRGNN   # 单模型/单数据集/单预算
```

结果写入 `datasets/<name>/result/<exp_style>/<Model>_<exp_style>.xlsx`
（HR@K、MRR@K、NDCG@K，K=10,20）。隐私–效用曲线由 `python Fig.py` 生成。

---

## 7. 复现论文表格

1. 生成 DP 数据（§5）；
2. 在 `non_dp` 与 `dp` 两种模式下，对全部基线 + EMHSR，遍历
   `ε ∈ {0.001, 0.01, 0.1, 1, 10, 100}`（逐次设置 `EMHSR_EPS`）；
3. `python summarize.py` → 对比表存于 `datasets/<name>/finalresult/`。

论文中 EMHSR 相对 SSRGNN 的提升为：三数据集 × {K=10,20} 共 6 组的平均相对提升。

---

## 8. 复用说明

异构图推荐骨干（`srs/`、`Utils/DataLoader/`）基于公开 **SERec / srs** 框架
（CRIPAC-DIG/srs）。EMHSR 的独创贡献为：边掩码保护阶段、严格 ε-LDP 分析（§4.2）
以及 EMHSR 模型定义（`srs/models/EMHSR.py`）。

---

## 9. 引用

```bibtex
@article{li2026emhsr,
  title   = {Edge-Mask based Heterogeneous Social-aware Session Recommendation
             with Multi-Category Sensitive Link Protection},
  author  = {Li, Gesu and Chen, Fukun},
  journal = {Neurocomputing},
  year    = {2026}
}
```
