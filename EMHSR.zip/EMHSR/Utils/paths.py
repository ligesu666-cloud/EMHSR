"""集中管理数据根目录，避免把绝对路径写死在源码里。

默认数据目录为仓库根下的 ``datasets/``；可通过环境变量
``EMHSR_DATA_ROOT`` 覆盖（指向你本地存放 raw / dp_* / result 的目录）。
"""
import os

_DEFAULT_DATA_ROOT = "datasets"


def data_root() -> str:
    """返回数据根目录的绝对路径。"""
    root = os.environ.get("EMHSR_DATA_ROOT", _DEFAULT_DATA_ROOT)
    return os.path.abspath(root)


def dataset_dir(dataset_name: str) -> str:
    """<root>/<dataset_name>/raw —— 原始（未加噪）数据目录。"""
    return os.path.join(data_root(), dataset_name, "raw")


def _eps_tag(epsilon) -> str:
    """规范化 ε 标签：1.0/1 -> '1'，0.1 -> '0.1'，避免 int/float 混用导致目录名不一致。"""
    e = float(epsilon)
    return str(int(e)) if e.is_integer() else str(e)


def dataset_dp_dir(dataset_name: str, epsilon: float, suffix: str = "") -> str:
    """<root>/<dataset_name>/dp_<epsilon><suffix> —— 差分隐私加噪数据目录。

    ``suffix`` 用于消融实验的数据变体，例如 ``dp_0.1_wo_uu`` 对应
    ``epsilon=0.1, suffix="_wo_uu"``。
    """
    return os.path.join(data_root(), dataset_name, f"dp_{_eps_tag(epsilon)}{suffix}")


def result_dir(dataset_name: str, exp_style: str) -> str:
    """<root>/<dataset_name>/result/<exp_style> —— 实验结果目录。"""
    return os.path.join(data_root(), dataset_name, "result", exp_style)


def finalresult_dir(dataset_name: str) -> str:
    return os.path.join(data_root(), dataset_name, "finalresult")
