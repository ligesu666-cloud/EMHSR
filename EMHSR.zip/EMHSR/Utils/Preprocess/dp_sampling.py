import os.path
import ast
import sys
import numpy as np
import pandas as pd
from Utils.paths import dataset_dir, dataset_dp_dir
import csv

# 兼容以 `python Utils/Preprocess/dp_sampling.py` 运行
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', '..')))

def laplace_mechanism(true_value, sensitivity, epsilon):
    beta = sensitivity / epsilon
    noisy_value = true_value + np.random.laplace(0, beta)
    return noisy_value
def NoiseAdjMatrix(adjacency_matrix,args):
    # 设置隐私参数
    #epsilon = 0.001  # 隐私预算
    #sensitivity = 1  # 数据项的敏感性（对于任何单个数据项）
    # 对邻接矩阵进行拉普拉斯随机响应
    noisy_adjacency_matrix = np.copy(adjacency_matrix)

    for i in range(adjacency_matrix.shape[0]):
        for j in range(adjacency_matrix.shape[1]):
            if adjacency_matrix[i, j] != 0:
                noisy_value = laplace_mechanism(adjacency_matrix[i, j], args.sensitivity, args.epsilon)
                noisy_adjacency_matrix[i, j] = 1 if noisy_value > 0 else 0

    return noisy_adjacency_matrix

def has_MulElements(df,check_name):
    # 检测items列中是否存在多个元素
    has_multiple_elements = df[check_name].str.split(',').apply(len) > 1
    if has_multiple_elements.any():
        return True
    else:
        return False

def DF2AdjMatrix(df,col_name,row_name):
    if df[row_name].dtype==object:
        df[row_name] = df[row_name].str.split(",")
        # 使用explode函数展开items列，并与userId列一一对应
        df = df.explode(row_name).astype(int)

    max_col = df[col_name].max()
    max_row = df[row_name].max()
    # 创建邻接矩阵
    adj_matrix = np.zeros((max_col + 1, max_row + 1))
    for _, row in df.iterrows():
        index_col = row[col_name]
        index_row = row[row_name]
        adj_matrix[index_col][index_row] = 1
    return adj_matrix

def Matrix2DF(df_original,noisy_matrix,col_name,row_name,col_style=None):
    nonzero_rows, nonzero_cols = np.nonzero(noisy_matrix)
    df = pd.DataFrame({col_name: nonzero_rows, row_name: nonzero_cols})

    if col_style=='mul':
        df[row_name]=df[row_name].astype(str)
        df_grouped=df.groupby([col_name])[row_name].apply(','.join).reset_index()

        df = df_original.merge(df_grouped, on=col_name, how='left')

        df[row_name]=df[f'{row_name}_y'].fillna(df[f'{row_name}_x'])
        # 将列的数据类型转换为字符串
        df[row_name] = df[row_name].astype(str)
        # 处理格式不一致的单元格
        df[row_name] = df[row_name].str.strip("[]")  # 删除方括号 []
        df[row_name] = df[row_name].str.replace("'", "")  # 删除单引号 '
        df[row_name] = df[row_name].str.replace('"', '')
        df[row_name] = df[row_name].str.replace(" ", "")


        df=df.drop([f'{row_name}_x',f'{row_name}_y'],axis=1).drop_duplicates()


    else:
        pass
    return df

def save_sessions(df_clicks, filepath):
    df_clicks = df_clicks.groupby('sessionId').agg({
        'userId':
        lambda col: col.iloc[0],
        'items':
        lambda col: ','.join(col.astype(str)),
    })
    df_clicks.to_csv(filepath, sep='\t', header=['userId', 'items'], index=True)


if __name__ == '__main__':
    from Train.ParserTrain import TrainParser
    args = TrainParser()
    args.epsilon = 0.001
    dataset_list = ['gowalla','delicious','brightkite']
    files = ['train','test','valid','edges']
    epsilon_list = [0.001, 0.01, 0.1, 1, 10, 100]
    for dataset_name in dataset_list:
        for epsilon in epsilon_list:
            args.epsilon = epsilon
            for file_name in files:
                save_path = dataset_dp_dir(dataset_name, args.epsilon) + '/'
                if not os.path.exists(save_path):
                    os.makedirs(save_path)
                if file_name == 'edges':
                    col_name = 'follower'
                    row_name = 'followee'
                    col_style = None
                else:
                    col_name = 'sessionId'
                    row_name = 'items'
                    col_style = 'mul'
                df = pd.read_csv(dataset_dir(dataset_name) + f'/{file_name}.txt', sep='\t')
                adj_matrix = DF2AdjMatrix(df, col_name, row_name)
                noise_matrix = NoiseAdjMatrix(adj_matrix, args)
                df = Matrix2DF(df, noise_matrix, col_name, row_name, col_style)
                if file_name == 'edges':
                    df.to_csv(save_path + f'{file_name}.txt', sep='\t', index=False)
                else:
                    save_sessions(df, save_path + f'{file_name}.txt')
