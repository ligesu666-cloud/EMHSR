"""按论文 §4.2 生成差分隐私边掩码数据集（dp_<epsilon> 切分）。

与 `Utils/Preprocess/dp_sampling.py`（legacy，复现投稿结果的 Laplace 版本）不同，
本脚本使用 `edge_mask.py` 中**严格对齐论文**的三种机制：
    * 用户–用户社交边 (UU) -> 随机响应 randomized_response_mask
    * 用户–项目交互  (UI) -> Laplace 机制        laplace_edge_mask
    * 项目–项目共现  (PP) -> 计数聚合            aggregate_item_item_mask

生成的数据与 train.py 完全兼容（edges.txt / train|valid|test.txt 格式一致）。

依赖：datasets/<name>/raw/{edges,train,valid,test}.txt
输出：datasets/<name>/dp_<epsilon>{_suffix}/{edges,train,valid,test}.txt

消融支持（--ablate）：
    uu  : UU 边不施加随机响应（原始社交边），UI/PP 仍加噪；
    ui  : UI 边不施加 Laplace（原始会话），UU 仍加噪；
    pp  : PP（item–item）结构在**模型层**通过 use_pp=False 关闭，
          数据层无需变体（复用 dp_<epsilon>）。

用法:
    python scripts/generate_dp_datasets.py --epsilon 0.1 --dataset gowalla --ablate uu
    EMHSR_DATA_ROOT=/path/to/data python scripts/generate_dp_datasets.py
"""
import os
import sys
import argparse

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from Utils.paths import dataset_dir, dataset_dp_dir
from Utils.Preprocess.dp_sampling import DF2AdjMatrix, Matrix2DF, save_sessions
from Utils.Preprocess.edge_mask import (
    laplace_edge_mask, randomized_response_mask, aggregate_item_item_mask,
)

DATASETS = ['gowalla', 'delicious', 'brightkite']
EPSILONS = [0.001, 0.01, 0.1, 1, 10, 100]


def _copy_raw(src, dst):
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    pd.read_csv(src, sep='\t').to_csv(dst, sep='\t', index=False)


def _eps_tag(epsilon):
    """与训练管线 dataset_dp_dir 的 f'dp_{epsilon}' 命名保持一致：
    1.0 -> '1'，10.0 -> '10'，0.1 -> '0.1'。"""
    return str(int(epsilon)) if float(epsilon).is_integer() else str(epsilon)


def generate_one(dataset_name, epsilon, ablate=None):
    """生成单个 (数据集, 隐私预算, 消融) 的 dp 数据切分。

    ablate in {None, 'uu', 'ui'}：
      * None : 完整 EMHSR（UU 随机响应 + UI Laplace + PP 聚合）
      * 'uu' : UU 边使用原始社交边（不随机响应），UI/PP 仍加噪
      * 'ui' : UI 边使用原始会话（不加 Laplace），UU 仍随机响应
    'pp' 在模型层处理（use_pp=False），此处复用完整 dp 数据，不做变体。
    """
    rng = np.random.RandomState(42)
    suffix = f"_{ablate}" if ablate else ""
    save = dataset_dp_dir(dataset_name, _eps_tag(epsilon), suffix) + '/'
    os.makedirs(save, exist_ok=True)

    # stats.txt 训练管线需要，但与扰动无关，直接从 raw 复制
    stats_src = dataset_dir(dataset_name) + '/stats.txt'
    if os.path.exists(stats_src):
        import shutil
        shutil.copy(stats_src, save + 'stats.txt')

    # ---- 用户–用户社交边 (UU) ----
    edges = pd.read_csv(dataset_dir(dataset_name) + '/edges.txt', sep='\t')
    adj_uu = DF2AdjMatrix(edges, 'follower', 'followee')
    if ablate == 'uu':
        # 消融：UU 不保护 -> 直接复制原始社交边
        df_edges = edges.copy()
    else:
        noisy_uu = randomized_response_mask(adj_uu, epsilon, rng)
        df_edges = Matrix2DF(edges, noisy_uu, 'follower', 'followee', None)
    df_edges.to_csv(save + 'edges.txt', sep='\t', index=False)

    # ---- 用户–项目交互 (UI) + 项目–项目 (PP) ----
    for fn in ['train', 'valid', 'test']:
        sess_path = dataset_dir(dataset_name) + f'/{fn}.txt'
        sess = pd.read_csv(sess_path, sep='\t')
        if ablate == 'ui':
            # 消融：UI 不保护 -> 直接复制原始会话
            df_sess = sess.copy()
        else:
            adj_ui = DF2AdjMatrix(sess, 'sessionId', 'items')
            noisy_ui = laplace_edge_mask(adj_ui, epsilon, rng=rng)
            df_sess = Matrix2DF(sess, noisy_ui, 'sessionId', 'items', 'mul')
        save_sessions(df_sess, save + f'{fn}.txt')

    print(f'[OK] {save}')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--epsilon', type=float, default=None,
                    help='仅生成该隐私预算；缺省则遍历 EPSILONS')
    ap.add_argument('--dataset', default=None,
                    choices=DATASETS + [None],
                    help='仅生成该数据集；缺省则遍历 DATASETS')
    ap.add_argument('--ablate', default=None, choices=[None, 'uu', 'ui'],
                    help='消融变体：uu / ui（pp 在模型层处理，无需数据变体）')
    a = ap.parse_args()

    dss = [a.dataset] if a.dataset else DATASETS
    epss = [a.epsilon] if a.epsilon is not None else EPSILONS
    for ds in dss:
        for eps in epss:
            generate_one(ds, eps, a.ablate)


if __name__ == '__main__':
    main()
