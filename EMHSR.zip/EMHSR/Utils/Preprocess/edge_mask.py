"""多类别敏感链接的边掩码保护机制（对应论文 §4.2）。

EMHSR 对三类关系分别施加不同的本地化差分隐私（LDP）扰动，构成
"边掩码异构图"。本模块把论文中的三种机制落成可运行代码：

  1) 用户–项目边 (UI)：Laplace 机制（论文定义 4.4 / 式 (4.7)）
     对每个非零交互元素 a_{i,j} 加 Laplace(sensitivity/ε) 噪声后阈值化，
     输出 1 当且仅当加噪值 > 0。由 Laplace 密度比上界 e^{ε}（论文定理 4.1）
     可知该逐边机制满足 ε-LDP。

  2) 项目–项目边 (PP)：聚合式掩码（论文式 (4.9)-(4.10)）
     由加噪后的用户–项目边聚合得到项目共现关系 A_{poi,poi}^{*}，
     在聚合阶段复用同一 ε，故整体仍满足 ε-LDP（后处理不变性，论文定理 4.5）。

  3) 用户–用户边 (UU)：随机响应机制（论文定义 4.5 / 式 (4.11)）
     以概率 p 保留原边、以概率 1-p 翻转，对应纯 ε-LDP，其中 ε = ln(p/(1-p))。

所有机制均为"逐元素独立"扰动，因此 n 个用户 / 边的联合发布仍满足纯 ε-DP，
且隐私预算 **不** 随数据规模放大（论文定理 4.6 / 并行组合）。
"""
import numpy as np


def laplace_edge_mask(adj_matrix, epsilon, sensitivity=1.0,
                      truncation_C=None, sample_q=1.0, rng=None):
    """用户–项目边的 Laplace 机制掩码（论文 §4.2.1）。

    机制 = 随机采样(率 q) + 截断 Laplace 噪声(上界 C) + 阈值化：
      1) 采样阶段：以公开可复现的随机性，仅对 q 比例的非零边施加扰动
         （未入选的边直接置 0，不进入发布图）；
      2) 扰动阶段：对入选的非零元素 a 加 Laplace(0, sensitivity/ε) 噪声，
         若 truncation_C 不为 None，则噪声截断到 [-C, C]；
      3) 阈值化：输出 1 当且仅当加噪值 > 0。

    隐私分析（对应论文 §4.2）：
      * 输入无关的噪声截断不改变密度比上界，仍满足 ε-LDP；
      * 公开随机采样与逐边 ε-LDP 机制组合的输出比为
        q·e^{ε} + (1-q) ≤ e^{ε}，故整体仍满足纯 ε-LDP；
      * 默认 truncation_C=None、sample_q=1.0 时与原 dp_sampling.py
        的逐边 Laplace+阈值化行为完全一致。

    Parameters
    ----------
    adj_matrix : np.ndarray
        二元邻接矩阵（0/1），非零元素为待保护的交互/链接。
    epsilon : float
        隐私预算 ε > 0。
    sensitivity : float
        逐元素敏感度，默认为 1（单个交互元素）。
    truncation_C : float or None
        噪声截断上界 C；None 表示不截断。实验取 C = sensitivity = 1。
    sample_q : float
        采样率 q ∈ (0, 1]；1.0 表示对全部非零边扰动。
    rng : np.random.RandomState, optional
        随机源（公开种子，保证可复现）。

    Returns
    -------
    np.ndarray
        加噪后的边掩码矩阵 A^*（0/1）。
    """
    rng = rng or np.random
    A = adj_matrix.astype(float)
    beta = sensitivity / epsilon
    noise = rng.laplace(0.0, beta, size=A.shape)
    if truncation_C is not None:
        noise = np.clip(noise, -float(truncation_C), float(truncation_C))
    nonzero = A != 0
    if sample_q < 1.0:
        perturb = nonzero & (rng.random(A.shape) < float(sample_q))
    else:
        perturb = nonzero
    out = np.where(perturb, A + noise, 0.0)
    return (out > 0).astype(int)


def randomized_response_mask(adj_matrix, epsilon, rng=None):
    """用户–用户边的随机响应掩码（论文 §4.2.3）。

    Parameters
    ----------
    adj_matrix : np.ndarray
        二元邻接矩阵（0/1）。
    epsilon : float
        隐私预算 ε > 0，对应保留概率 p = e^{ε}/(e^{ε}+1)。

    Returns
    -------
    np.ndarray
        加噪后的边掩码矩阵 A^*（0/1），满足纯 ε-LDP。
    """
    rng = rng or np.random
    p = np.exp(epsilon) / (1.0 + np.exp(epsilon))  # = 1/(1+e^{-ε})
    mask = rng.random(adj_matrix.shape) < p  # True=保留
    return np.where(mask, adj_matrix, 1 - adj_matrix).astype(int)


def aggregate_item_item_mask(ui_mask, epsilon=1.0, sensitivity=1.0, rng=None):
    """项目–项目边的聚合式掩码（论文 §4.2.2）。

    由加噪后的用户–项目边 ui_mask 聚合得到项目共现矩阵，
    再对聚合计数施加 Laplace 噪声（敏感度 1）后阈值化。

    Parameters
    ----------
    ui_mask : np.ndarray
        加噪后的用户–项目二元边掩码（用户×项目）。
    epsilon : float
        隐私预算。
    sensitivity : float
        聚合计数的逐元素敏感度，默认为 1。

    Returns
    -------
    np.ndarray
        加噪后的项目–项目边掩码矩阵（项目×项目，0/1）。
    """
    rng = rng or np.random
    # 聚合：项目 i 与项目 j 的共现次数 = ui_mask^T @ ui_mask
    cooccur = ui_mask.astype(float).T @ ui_mask.astype(float)
    np.fill_diagonal(cooccur, 0.0)
    beta = sensitivity / epsilon
    noisy = cooccur + rng.laplace(0.0, beta, size=cooccur.shape)
    return (noisy > 0).astype(int)


def mask_relation(adj_matrix, kind, epsilon, sensitivity=1.0,
                  truncation_C=None, sample_q=1.0, rng=None):
    """根据关系类别分发到对应的边掩码机制。

    kind: 'ui' (用户-项目, Laplace) | 'uu' (用户-用户, 随机响应)
          | 'pp' (项目-项目, 聚合式，需传入 ui_mask 而非邻接矩阵)
    """
    if kind == 'ui':
        return laplace_edge_mask(adj_matrix, epsilon, sensitivity,
                                 truncation_C, sample_q, rng)
    if kind == 'uu':
        return randomized_response_mask(adj_matrix, epsilon, rng)
    raise ValueError(f"未知的边掩码类型: {kind}（pp 请调用 aggregate_item_item_mask）")
