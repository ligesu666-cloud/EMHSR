import argparse
def DataParser():
    parser=argparse.ArgumentParser()
    parser.add_argument("--max_len",
                        type=float,
                        default=50,
                        help='max_len')
    parser.add_argument("--max_users",
                        type=float,
                        default=1000,
                        help="max number of users"
                        )
    parser.add_argument("--train_split",
                        type=float,
                        default=0.6,
                        help="train splite ratio")
    return parser.parse_args()