import os
import pandas as pd
from Utils.Preprocess.utils_processdata import *
from sklearn.preprocessing import LabelEncoder
from Utils.Preprocess.ProprecessParser import *
from Utils.paths import data_root
class ProcessDatasets():
    def __init__(self,dataset_name,args):
        self.dataset_name=dataset_name
        self.args=args
        self.dataset_path = os.path.join(data_root(), dataset_name, 'raw') + '/'
        self.clicks,self.edges=self.GetFilePath()


    def GetFilePath(self):
        FILENAMES = {
                'gowalla': ['Gowalla_totalCheckins.txt', 'Gowalla_edges.txt'],
                'delicious': [
                    'user_taggedbookmarks-timestamps.dat',
                    'user_contacts-timestamps.dat',
                ],
                'brightkite': [
                    'Brightkite_totalCheckins.txt',
                    'Brightkite_edges.txt',
                ],
            }
        filenames=FILENAMES[self.dataset_name]
        clicks = self.dataset_path+filenames[0]
        edges = self.dataset_path+filenames[1]
        return clicks,edges
    def ReadData(self):
        if self.dataset_name=='gowalla':
            self.args.interval = pd.Timedelta(days=1)
            self.args.max_items = 50000
            df = pd.read_csv(
                        self.clicks,
                        sep='\t',
                        header=None,
                        names=['userId', 'timestamp', 'latitude', 'longitude', 'itemId'],
                        parse_dates=['timestamp'],
                        infer_datetime_format=True,
                    )

            df_clicks = df[['userId', 'timestamp', 'itemId']]
            df_loc = df.groupby('itemId').agg({
                'latitude': lambda col: col.iloc[0],
                'longitude': lambda col: col.iloc[0],
            }).reset_index()

            df_edges = pd.read_csv(self.edges, sep='\t', header=None, names=['follower', 'followee'])
        elif self.dataset_name=='brightkite':
            self.args.interval = pd.Timedelta(days=1)
            self.args.max_items = 50000
            df = pd.read_csv(
                self.clicks,
                sep='\t',
                header=None,
                names=['userId', 'timestamp', 'latitude', 'longitude', 'itemId'],
                parse_dates=['timestamp'],
                infer_datetime_format=True,
            )

            LE=LabelEncoder()
            df['itemId']=LE.fit_transform(df['itemId'])
            df_clicks = df[['userId', 'timestamp', 'itemId']]
            df_loc = df.groupby('itemId').agg({
                'latitude': lambda col: col.iloc[0],
                'longitude': lambda col: col.iloc[0],
            }).reset_index()

            df_edges = pd.read_csv(self.edges, sep='\t', header=None, names=['follower', 'followee'])
        elif self.dataset_name=='delicious':
            df_clicks = pd.read_csv(
                self.clicks,
                sep='\t',
                skiprows=1,
                header=None,
                names=['userId', 'sessionId', 'itemId', 'timestamp'],
            )
            df_clicks['timestamp'] = pd.to_datetime(df_clicks.timestamp, unit='ms')
            df_loc = None
            df_edges = pd.read_csv(
                self.edges,
                sep='\t',
                skiprows=1,
                header=None,
                usecols=[0, 1],
                names=['follower', 'followee'],
            )
        return df_clicks,df_edges,df_loc

    def ProcessData(self):
        self.args.dataset_name=self.dataset_name
        self.args.output_dir=self.dataset_path
        df_clicks,df_edges,df_loc=self.ReadData()
        df_edges = df_edges[df_edges.follower != df_edges.followee]
        df_clicks = df_clicks.dropna()
        df_clicks, df_edges = update_id(
            df_clicks, df_edges, colnames=['userId', 'followee', 'follower']
        )
        if df_loc is None:
            df_clicks = update_id(df_clicks, colnames='itemId')
        else:
            df_clicks, df_loc = update_id(df_clicks, df_loc, colnames='itemId')
        df_clicks = df_clicks.sort_values(['userId', 'timestamp'])
        np.random.seed(123456)
        preprocess(df_clicks, df_edges, df_loc, args)

args=DataParser()
ProcessDatasets('delicious',args).ProcessData()

