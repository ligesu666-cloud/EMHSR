from collections import defaultdict
import logging
import time

import pandas as pd
import torch as th
from torch import nn,optim
def evaluate(model, data_loader, prepare_batch, Ks=[20]):
    model.eval()
    results = defaultdict(float)
    max_K = max(Ks)
    num_samples = 0
    with th.no_grad():
        for batch in data_loader:
            inputs, labels = prepare_batch(batch)
            logits = model(*inputs)
            batch_size = logits.size(0)
            num_samples += batch_size
            topk = th.topk(logits, k=max_K, sorted=True)[1]
            labels = labels.unsqueeze(-1)
            for K in Ks:
                hit_ranks = th.where(topk[:, :K] == labels)[1] + 1
                hit_ranks = hit_ranks.float().cpu()
                results[f'HR@{K}'] += hit_ranks.numel()
                results[f'MRR@{K}'] += hit_ranks.reciprocal().sum().item()
                results[f'NDCG@{K}'] += th.log2(1 + hit_ranks).reciprocal().sum().item()
    for metric in results:
        results[metric] /= num_samples
    return results

def fix_weight_decay(model, ignore_list=['bias', 'batch_norm']):
    decay = []
    no_decay = []
    logging.debug('ignore weight decay for ' + ', '.join(ignore_list))
    for name, param in model.named_parameters():
        if not param.requires_grad:
            continue
        if any(map(lambda x: x in name, ignore_list)):
            no_decay.append(param)
        else:
            decay.append(param)
    params = [{'params': decay}, {'params': no_decay, 'weight_decay': 0}]
    return params

def print_results(*results_list):
    metrics = list(results_list[0][1].keys())
    logging.warning('Metric\t' + '\t'.join(metrics))
    for name, results in results_list:
        logging.warning(
            name + '\t' +
            '\t'.join([f'{round(results[metric] * 100, 2):.2f}' for metric in metrics])
        )

def dict2df(dict_data,row_name):
    data_keys=list(dict_data.keys())
    data_values=list(dict_data.values())
    df=pd.DataFrame([data_values],columns=data_keys)
    df=df.rename(index={0:row_name})
    return df