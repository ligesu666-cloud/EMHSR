import matplotlib.pyplot as plt
import os
import sys
import pandas as pd

# 允许以 `python Fig.py` 直接运行（仓库根目录在 sys.path 中）
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from Utils.paths import dataset_dir, finalresult_dir

dataset_list=['gowalla','brightkite','delicious']
metric_name = ['HR', 'MRR', 'NDCG']
top_k_list=[10,20]
x_label = [0.001, 0.01, 0.1, 1, 10, 100]
x = range(len(x_label))
colorstyle = ['b', 'r', 'y', 'Skyblue', 'pink', 'orange']
linestyle_list = ['-', '--', '-.', ':', 'dashed', 'dashdot']
for top_k in top_k_list:
    fig, axs = plt.subplots(3, 1, figsize=(5, 10))
    for i in range(len(dataset_list)):
        contrast_path = os.path.join(finalresult_dir(dataset_list[i]), 'SERec_dp_contrast.xlsx')
        df=pd.read_excel(contrast_path)
        for k in range(len(metric_name)):
            axs[i].plot(x,df[f'{metric_name[k]}@{top_k}'],color=colorstyle[k],linestyle=linestyle_list[k],label=metric_name[k])
        axs[i].set_xticks(x)
        axs[i].set_xticklabels(x_label)
        axs[i].set_xlabel('$\epsilon$')
        axs[i].set_ylabel('Value')
        axs[i].legend()
        axs[i].set_title(f'{dataset_list[i]} @{top_k} in different budgets comparison results')
        axs[i].legend(loc='upper right')

    plt.tight_layout()
    Fig_path=f'./Fig/'
    os.makedirs(Fig_path,exist_ok=True)
    plt.savefig(Fig_path+f'{top_k}.png')
    plt.savefig(Fig_path+f'{top_k}.pdf')
    plt.show()