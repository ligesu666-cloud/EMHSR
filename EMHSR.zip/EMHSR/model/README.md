# 表10 隐私保护基线复现模型（协议适配版）

本目录包含论文表 `tab:dp-comparison-utility` 中四个隐私保护基线的
机制级复现。四个方法均为独立论文提出，官方代码不可用
（DPLCF / Improved DP-CF / 社区级 LDP 无公开代码；
LPGNN 官方代码 `github.com/sisaman/LPGNN` 仅支持节点分类，
无法产出会话推荐 HR@20），故按各论文描述复现核心隐私机制，
并适配到本稿统一的实验协议。

## 统一协议（与主实验一致）

- 数据：`data712/<ds>/raw/`，7:1:2 时间顺序划分；
- 扰动预算：ε = 0.1（seed = 42）；
- 评测：会话前缀 → 下一物品，全物品排序，HR@10 / HR@20 / NDCG@20；
- 会话扩展与主实验 `AugmentedDataset` 完全一致。

## 模型与复现保真度

| 文件 | 方法 | 复现的隐私机制 | 协议适配点 |
|---|---|---|---|
| `dplcf.py` | DPLCF（Gao et al., SIGIR 2020） | 随机位翻转（AP 非对称，ε-LDP）+ 服务器无偏联合概率估计 + 物品余弦相似度 | 用户画像 = train 内交互物品；查询 = 会话前缀（本地原始数据，与原文"本地推理"分工一致） |
| `improved_dpcf.py` | Improved DP-CF（Yin et al., J. Supercomputing 2020） | DiffGen 式 ε-DP 决策树（指数机制分裂 + Laplace 叶直方图，ε_tree+ε_hist=ε）+ 时间因子 | 属性 =（活跃度分桶, 新近度分桶）；服务器仅在合成数据上训练 CF |
| `lpgnn_rec.py` | LPGNN（Sajadmanesh & Gatica-Perez, CCS 2021） | 官方 1-bit 机制（1BM，对称 GRR）+ KProp 二跳聚合去噪 + GCN | 节点 = 用户+物品二部图；打分 = 用户表示与物品嵌入内积；ε 全部用于特征通道（原文特征/标签双通道，本协议标签为服务器端训练集） |
| `community_ldp.py` | 社区级 LDP 社交推荐（Guo et al., Inf. Sci. 2023） | 社交边随机响应（ε/2）→ 扰动图标签传播社区 → 同社区+交互相似建细粒度社交图；交互画像 GRR（ε/2） | 打分 = (1-α)·CF + α·社交邻居画像；α=0.3 |

## 运行

```bash
python scripts/run_dp_baselines.py --dataset gowalla --all
python scripts/run_dp_baselines.py --dataset delicious --baseline dplcf
```

结果写入 `data712/<ds>/result/dp_baselines/results.csv`
（列：dataset, baseline, epsilon, seed, HR@10, HR@20, NDCG@20, num_pairs, seconds）。

## 诚实性说明

- 以上数值为**本文复现（协议适配）**结果，非各原文官方代码在原文
  数据集/任务上的结果；表 10 的表述与脚注均已注明。
- 复现保留了各方法的隐私机制与预算分配；推荐骨干（物品级 CF / 简单
  GNN）按原文范式实现，未针对会话推荐任务做强任务特定优化。
