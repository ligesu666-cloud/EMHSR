# -*- coding: utf-8 -*-
"""Improved DP-CF 复现（Yin et al., "Improved collaborative filtering
recommendation algorithm based on differential privacy protection",
The Journal of Supercomputing 2020）。

原文机制（无官方代码，按论文摘要与 DiffGen 框架复现）：
  1. DiffGen 式 ε-DP 数据发布：以差分隐私决策树对用户数据做匿名化合成
     —— 树节点分裂用指数机制（ε_tree），叶节点保存敏感值（物品）直方图
     并加 Laplace 噪声（ε_hist）；服务器仅在发布的合成数据上训练 CF。
  2. 时间因子：交互按时间新近度加权，越新的行为权重越高。
  3. 推荐：在合成数据的物品相似度上做时间加权物品级 CF。

协议适配：用户记录属性取（活跃度分桶、新近度分桶），
敏感值为用户交互的物品；"服务器端 CF"在合成矩阵上估计物品余弦相似度，
"本地推理"使用原始会话前缀 + 时间因子加权（与原文客户端/服务器分工一致）。
隐私预算组成：ε_tree + ε_hist = ε（顺序组合）。
"""
import numpy as np

from .common import enumerate_pairs


class ImprovedDPCF:
    def __init__(self, epsilon, num_users, num_items, depth=3,
                 top_m=100, n_synth_per_user=50, time_lambda=0.2, seed=42):
        self.eps = float(epsilon)
        self.num_users = num_users
        self.num_items = num_items
        self.depth = depth
        self.top_m = top_m
        self.n_synth = n_synth_per_user
        self.time_lambda = time_lambda
        self.seed = seed

    # ------------------------------------------------------------------
    def fit(self, df_train):
        rng = np.random.RandomState(self.seed)
        n_sessions = len(df_train)
        # 用户级记录：属性（活跃度分桶, 新近度分桶），敏感值 = 交互物品
        records = []  # (attr_tuple, items_list)
        u_sessions, u_lastpos = {}, {}
        for pos, (_, row) in enumerate(df_train.iterrows()):
            u = int(row['userId'])
            u_sessions.setdefault(u, []).extend(row['items'])
            u_lastpos[u] = max(u_lastpos.get(u, -1), pos)
        act_q = np.quantile([len(v) for v in u_sessions.values()],
                            [0.25, 0.5, 0.75])
        rec_q = np.quantile(list(u_lastpos.values()), [0.25, 0.5, 0.75])
        for u, items in u_sessions.items():
            act = int(np.searchsorted(act_q, len(items)))
            rec = int(np.searchsorted(rec_q, u_lastpos[u]))
            records.append(((act, rec), items))
        user_attr = {u: (int(np.searchsorted(act_q, len(items))),
                         int(np.searchsorted(rec_q, u_lastpos[u])))
                     for u, items in u_sessions.items()}
        # 全局 top-M 敏感值域（直方图支撑集）
        from collections import Counter
        cnt = Counter(it for _, items in records for it in items)
        self.top_items = [it for it, _ in cnt.most_common(self.top_m)]
        top_set = set(self.top_items)
        item2col = {it: c for c, it in enumerate(self.top_items)}

        # ---- DiffGen：ε-DP 决策树 ------------------------------------
        eps_tree, eps_hist = self.eps / 2.0, self.eps / 2.0
        hist_top = np.zeros(len(self.top_items))
        for _, items in records:
            for it in items:
                if it in top_set:
                    hist_top[item2col[it]] += 1
        tree = self._build_tree(
            records, list(range(len(records))),
            [hist_top.copy()], eps_tree, eps_hist, 0, rng)

        # ---- 合成数据：逐用户从叶直方图采样 ---------------------------
        X_syn = np.zeros((self.num_users, self.num_items), dtype=np.float32)
        for u, items in u_sessions.items():
            attr = user_attr[u]
            leaf = self._route(tree, attr)
            probs = np.clip(leaf['noisy_hist'], 0, None)
            if probs.sum() <= 0:
                probs = np.ones_like(probs)
            probs = probs / probs.sum()
            k = min(self.n_synth, max(len(items), 1))
            sampled = rng.choice(len(self.top_items), size=k, p=probs)
            for c in sampled:
                X_syn[u, self.top_items[c]] = 1.0
        # 合成矩阵上的物品余弦相似度（服务器端 CF）
        norm = np.linalg.norm(X_syn, axis=0, keepdims=True) + 1e-12
        Xn = X_syn / norm
        sim = Xn.T @ Xn
        np.fill_diagonal(sim, 1.0)  # 自相似度（重复消费信号）
        self.sim = sim.astype(np.float32)
        return self

    def _hist_split_gain(self, records, idxs, attr, thr, item2col, m):
        left = np.zeros(m); right = np.zeros(m)
        for i in idxs:
            a, items = records[i]
            tgt = left if a[attr] <= thr else right
            for it in items:
                c = item2col.get(it)
                if c is not None:
                    tgt[c] += 1
        return float(np.abs(left - right).sum()), left, right

    def _build_tree(self, records, idxs, sibling_hists, eps_tree, eps_hist,
                    depth, rng):
        m = len(self.top_items)
        item2col = {it: c for c, it in enumerate(self.top_items)}
        # 叶直方图：真值 + Laplace(1/ε_hist)（每个用户只落入一个叶 → 并行组合）
        hist = np.zeros(m)
        for i in idxs:
            for it in records[i][1]:
                c = item2col.get(it)
                if c is not None:
                    hist[c] += 1
        noisy = hist + rng.laplace(1.0 / eps_hist, size=m)
        node = {'hist': hist, 'noisy_hist': noisy, 'leaf': True}
        if depth >= self.depth or len(idxs) < 8:
            return node
        # 指数机制选分裂（效用 = 子节点敏感值分布差异）
        n_split = 2 ** self.depth - 1
        eps_s = eps_tree / n_split
        cands = [(a, t) for a in range(2) for t in range(1, 4)]
        utils, hists = [], []
        for a, t in cands:
            u, hl, hr = self._hist_split_gain(records, idxs, a, t, item2col, m)
            utils.append(u); hists.append((hl, hr))
        utils = np.asarray(utils)
        w = np.exp(eps_s * (utils - utils.max()) / 2.0)
        w = w / w.sum()
        a, t = cands[rng.choice(len(cands), p=w)]
        hl, hr = hists[cands.index((a, t))]
        left_idx = [i for i in idxs if records[i][0][a] <= t]
        right_idx = [i for i in idxs if records[i][0][a] > t]
        if not left_idx or not right_idx:
            return node
        node.update({'leaf': False, 'attr': a, 'thr': t})
        node['left'] = self._build_tree(records, left_idx, None, eps_tree,
                                        eps_hist, depth + 1, rng)
        node['right'] = self._build_tree(records, right_idx, None, eps_tree,
                                         eps_hist, depth + 1, rng)
        return node

    def _route(self, node, attrs):
        while not node['leaf']:
            node = node['left'] if attrs[node['attr']] <= node['thr'] \
                else node['right']
        return node

    # ------------------------------------------------------------------
    def cumsum_scores(self, seq):
        """时间因子加权前缀打分：越新的物品权重越高。"""
        L = len(seq)
        out = np.zeros((L - 1, self.num_items), dtype=np.float32)
        acc = np.zeros(self.num_items, dtype=np.float32)
        lam = self.time_lambda
        for l in range(L - 1):
            w = float(np.exp(-lam * (L - 2 - l)))
            acc = acc + w * self.sim[seq[l]]
            out[l] = acc
        return out

    def evaluate(self, df_test, ks=(10, 20)):
        return enumerate_pairs(
            df_test, lambda row: self.cumsum_scores(list(row['items'])),
            self.num_items, ks)
