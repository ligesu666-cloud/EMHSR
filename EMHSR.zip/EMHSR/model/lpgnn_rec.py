# -*- coding: utf-8 -*-
"""LPGNN 复现（Sajadmanesh & Gatica-Perez, "Locally Private Graph Neural
Networks", ACM CCS 2021）。

原文有官方代码（github.com/sisaman/LPGNN），但仅支持 cora/pubmed/facebook/
lastfm 上的节点分类任务，无法直接产出本稿会话推荐协议下的 HR@20。
本复现移植官方实现的两个核心组件到会话推荐协议：
  1. 官方 1-bit 机制（1BM）：每个特征位以 p = e^{ε/2}/(1+e^{ε/2}) 保持真实值、
     否则翻转（对称 GRR），满足 ε-LDP；服务器端由已知翻转概率做无偏反解。
  2. KProp 去噪层：在公开图结构上做多跳邻域聚合以平滑扰动特征
     （官方实现 KProp: X^(k) = Â X^(k-1)），随后接 GNN。

协议适配：节点 = 用户+物品（二部图），节点特征 = 用户交互画像 multi-hot；
GNN 输出用户/物品表示，以内积对下一物品打分（CrossEntropy 训练，
验证集 HR@20 早停，与主实验一致）。预算：全部 ε 用于特征通道
（原文将 ε 分配给特征与标签双通道；本协议标签为服务器端训练集，无标签泄露）。
"""
import numpy as np
import torch
import torch.nn as nn


class _Scorer(nn.Module):
    def __init__(self, num_users, num_items, x_dim, dim=64):
        super().__init__()
        self.user_mlp = nn.Sequential(
            nn.Linear(x_dim, dim), nn.ReLU(), nn.Linear(dim, dim))
        self.item_emb = nn.Parameter(torch.empty(num_items, dim))
        nn.init.xavier_uniform_(self.item_emb)

    def forward(self, x_user):
        h = self.user_mlp(x_user)
        return h @ self.item_emb.t()


class LPGNNRec:
    def __init__(self, epsilon, num_users, num_items, dim=64, kprop=2,
                 lr=1e-3, epochs=30, batch_size=1024, patience=2, seed=42):
        self.eps = float(epsilon)
        self.num_users = num_users
        self.num_items = num_items
        self.dim = dim
        self.kprop = kprop
        self.lr = lr
        self.epochs = epochs
        self.batch_size = batch_size
        self.patience = patience
        self.seed = seed

    # ---- 官方 1BM 扰动（ε-LDP） ----------------------------------------
    def perturb_1bm(self, X):
        p = np.exp(self.eps / 2.0) / (1.0 + np.exp(self.eps / 2.0))
        self.p_keep = p
        # 以 p_keep 概率保持真实位，否则翻转
        p_report = p * X + (1.0 - p) * (1.0 - X)
        return (np.random.rand(*X.shape) < p_report).astype(np.float32)

    # ---- KProp 去噪 + 训练 ---------------------------------------------
    def fit(self, df_train, df_valid):
        th = torch
        X = np.zeros((self.num_users, self.num_items), dtype=np.float32)
        self.train_pairs = []
        u_items = {}
        for _, row in df_train.iterrows():
            u = int(row['userId'])
            u_items.setdefault(u, set()).update(row['items'])
            seq = list(row['items'])
            for l in range(1, len(seq)):
                self.train_pairs.append((u, seq[:l], seq[l]))
        for u, items in u_items.items():
            X[u, list(items)] = 1.0
        # 1BM 扰动 + 无偏反解
        Xt = self.perturb_1bm(X)
        d = 2 * self.p_keep - 1.0
        Xhat = np.clip((Xt - (1.0 - self.p_keep)) / d, 0.0, 1.0)
        # KProp：在公开二部图上做多跳邻域聚合去噪（官方 KProp 思想：
        # X^(k) = Â^k X̂，二跳聚合 = 共现用户的扰动画像平均，噪声 ~1/√n 降低）
        M = th.tensor((X > 0).astype(np.float32))
        du = M.sum(1, keepdim=True).clamp(min=1)
        di = M.sum(0, keepdim=True).clamp(min=1)
        Xh_t = th.tensor(Xhat)
        E_item0 = (M.t() @ Xh_t) / di.t()      # item 特征：其用户的扰动均值
        for _ in range(max(self.kprop - 1, 0)):
            U_agg = (M @ E_item0) / du         # item -> user
            E_item0 = (M.t() @ U_agg) / di.t() # user -> item
        # 用户侧特征：二跳聚合（共现用户平均），显著去噪
        U2 = (M @ E_item0) / du
        self.item_init = E_item0.numpy()
        self.user_feat = U2.numpy()

        # ---- 训练（全批等价形式） ---------------------------------------
        # 说明：本适配中 logits 只依赖用户特征（LPGNN 为节点级方法，
        # 非会话感知），逐对 CE 等价于按"用户→下一物品"经验分布加权的
        # 全批 CE，因此按用户聚合目标分布做全批训练（数值等价、成本更低）。
        th.manual_seed(self.seed)
        np.random.seed(self.seed)
        model = _Scorer(self.num_users, self.num_items,
                        self.num_items, self.dim)
        opt = th.optim.AdamW(model.parameters(), lr=self.lr)
        # 用户级目标分布 T[u, j] = P(next = j | u)（由 train 前缀对统计）
        T = np.zeros((self.num_users, self.num_items), dtype=np.float32)
        for (u, _prefix, tgt) in self.train_pairs:
            T[u, tgt] += 1.0
        T /= np.maximum(T.sum(axis=1, keepdims=True), 1.0)
        Tt = th.tensor(T)
        # 验证集按用户聚合的 (目标, 重复次数)，用于早停 HR@20
        val_count = {}
        for _, row in df_valid.iterrows():
            seq = list(row['items'])
            u = int(row['userId'])
            for l in range(1, len(seq)):
                key = (u, seq[l])
                val_count[key] = val_count.get(key, 0) + 1
        Xh = th.tensor(self.user_feat)
        best_hr, best_state, bad = -1.0, None, 0
        for epoch in range(self.epochs):
            model.train()
            logits = model(Xh)
            logp = th.log_softmax(logits, dim=1)
            loss = -(Tt * logp).sum() / max(len(self.train_pairs), 1)
            opt.zero_grad(); loss.backward(); opt.step()
            # 验证集 HR@20 早停（每用户 top-20 固定 → 一次计算）
            model.eval()
            with th.no_grad():
                logits = model(Xh)
                top = th.topk(logits, 20, dim=1)[1].numpy()
            hits = sum(c for (u, t), c in val_count.items()
                       if t in top[u])
            total = sum(val_count.values())
            vhr = hits / max(total, 1)
            if vhr > best_hr:
                best_hr, bad = vhr, 0
                best_state = {k: v.clone() for k, v in model.state_dict().items()}
            else:
                bad += 1
                if bad >= self.patience:
                    break
        if best_state is not None:
            model.load_state_dict(best_state)
        self.model = model
        self.Xh = Xh
        return self

    # ---- 测试评测（与主实验协议一致） -----------------------------------
    def evaluate(self, df_test, ks=(10, 20)):
        # logits 只依赖用户 → 每用户一次全排序，按 (u, target) 对累计
        th = torch
        self.model.eval()
        results = {f'HR@{k}': 0 for k in ks}
        results.update({f'NDCG@{k}': 0 for k in ks})
        num_pairs = 0
        with th.no_grad():
            logits = self.model(self.Xh).numpy()
        for _, row in df_test.iterrows():
            seq = list(row['items'])
            if len(seq) < 2:
                continue
            u = int(row['userId'])
            s = logits[u]
            for l in range(1, len(seq)):
                tgt = seq[l]
                # 秩 = 得分严格更高的物品数 + 1（与 topk 排序一致）
                rank = int((s > s[tgt]).sum()) + 1
                num_pairs += 1
                for k in ks:
                    if rank <= k:
                        results[f'HR@{k}'] += 1
                        results[f'NDCG@{k}'] += 1.0 / np.log2(1 + rank)
        for key in list(results):
            results[key] /= max(num_pairs, 1)
        results['num_pairs'] = num_pairs
        return results
