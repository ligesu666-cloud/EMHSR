# -*- coding: utf-8 -*-
"""基线复现共享工具：数据加载、统一评测协议、批量打分。

评测协议与主实验完全一致：
  * 数据：data712/<ds>/raw/ 的 7:1:2 时间划分（train/valid/test.txt）；
  * 会话扩展：与 Utils.DataLoader.load.create_index 相同，
    对每个会话枚举 (items[:l] -> items[l])，l = 1..len-1；
  * 指标：对全部物品排序，HR@K = 目标物品进入 Top-K 的比例。
"""
import os
import sys

import numpy as np
import pandas as pd

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, REPO)


def load_data(data_root, dataset):
    """返回 (train_df, valid_df, test_df, num_users, num_items)。"""
    raw = os.path.join(data_root, dataset, 'raw')
    stats = pd.read_csv(os.path.join(raw, 'stats.txt'), sep='\t').iloc[0]
    from Utils.DataLoader.load import read_sessions
    df_train = read_sessions(os.path.join(raw, 'train.txt'))
    df_valid = read_sessions(os.path.join(raw, 'valid.txt'))
    df_test = read_sessions(os.path.join(raw, 'test.txt'))
    return df_train, df_valid, df_test, int(stats.num_users), int(stats.num_items)


def load_social(data_root, dataset):
    """返回边列表 ndarray (E, 2)（follower, followee）。"""
    edges = pd.read_csv(
        os.path.join(data_root, dataset, 'raw', 'edges.txt'), sep='\t')
    return edges[['follower', 'followee']].to_numpy(dtype=int)


def build_user_profiles(df_train, num_users, num_items, decay=None):
    """用户画像二值矩阵 X (num_users × num_items)。

    decay: 若给定，按会话在 train 中的时间顺序施加指数衰减加权
    （Yin et al. 2020 的时间因子），返回加权矩阵而非 0/1 矩阵。
    """
    X = np.zeros((num_users, num_items), dtype=np.float32)
    n_sessions = len(df_train)
    for pos, (_, row) in enumerate(df_train.iterrows()):
        u = int(row['userId'])
        w = 1.0
        if decay is not None:
            # 时间因子：越新的会话权重越高（指数衰减）
            w = float(np.exp(-decay * (n_sessions - 1 - pos) / max(n_sessions - 1, 1)))
        for it in row['items']:
            X[u, it] = max(X[u, it], w)
    return X


def enumerate_pairs(df, score_fn, num_items, ks=(10, 20)):
    """统一评测：对 df 中每个会话枚举 (prefix -> next) 对并累计命中。

    score_fn(row) -> (len-1, num_items) ndarray：
    返回逐前缀的得分矩阵（第 l 行 = 以 items[:l+1] 为查询的打分）。
    """
    results = {f'HR@{k}': 0 for k in ks}
    results.update({f'NDCG@{k}': 0 for k in ks})
    num_pairs = 0
    max_k = max(ks)
    for _, row in df.iterrows():
        seq = list(row['items'])
        if len(seq) < 2:
            continue
        scores = score_fn(row)  # (len-1, num_items)
        for l in range(1, len(seq)):
            target = seq[l]
            s = scores[l - 1]
            top = np.argpartition(-s, min(max_k, len(s) - 1))[:max_k]
            rank = np.where(top == target)[0]
            num_pairs += 1
            for k in ks:
                if len(rank) and rank[0] < k:
                    r = int(rank[0]) + 1
                    results[f'HR@{k}'] += 1
                    results[f'NDCG@{k}'] += 1.0 / np.log2(1 + r)
    for key in results:
        results[key] = results[key] / max(num_pairs, 1)
    results['num_pairs'] = num_pairs
    return results


def cumulative_cf_scores(seq, sim, num_items):
    """前缀累加打分：score(l) = sum_{i in seq[:l+1]} sim[i]。

    仅返回前 len-1 个前缀（第 l-1 行对应前缀 items[:l]）。
    """
    L = len(seq)
    out = np.zeros((L - 1, num_items), dtype=np.float32)
    acc = np.zeros(num_items, dtype=np.float32)
    for l in range(L - 1):
        acc = acc + sim[seq[l]]
        out[l] = acc
    return out


def set_seed(seed):
    import random
    random.seed(seed)
    np.random.seed(seed)
