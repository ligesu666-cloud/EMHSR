# -*- coding: utf-8 -*-
"""DPLCF 复现（Gao et al., "DPLCF: Differentially Private Local Collaborative
Filtering", SIGIR 2020）。

原文机制（无官方代码，按论文描述复现）：
  1. 本地扰动：每个用户对二值交互画像做随机位翻转（random bit-flip）后上报。
     - 对称翻转（DPLCF-SP）：翻转概率 p = 1/(1+e^ε)；
     - 非对称翻转（DPLCF-AP）：P(ỹ=1|y=1)=e^ε/(1+e^ε)，P(ỹ=1|y=0)=1/(1+e^ε)。
     原文指出稀疏数据上 AP 更优，本复现默认 AP（两者均满足 ε-LDP）。
  2. 服务器估计：由扰动矩阵无偏估计物品共现概率 p_ij 与边缘 p_i，
     进而得到物品相似度（余弦），该步骤不接触任何用户原始数据。
  3. 推荐：服务器将相似度矩阵下发，用户设备基于本地原始行为
     （本协议中为会话前缀物品）做物品级协同过滤打分。

协议适配：原文为 App 使用/MovieLens 评分场景；
本复现保持机制不变，将"用户画像"取 train 划分内的交互物品集合，
"本地推理"改为会话级下一物品预测（前缀物品为查询）。
"""
import numpy as np

from .common import build_user_profiles, cumulative_cf_scores, enumerate_pairs


class DPLCF:
    def __init__(self, epsilon, num_users, num_items, mode='AP',
                 topk_neighbors=200):
        self.eps = float(epsilon)
        self.num_users = num_users
        self.num_items = num_items
        self.mode = mode
        self.topk = topk_neighbors

    # ---- 步骤 1：本地随机位翻转（ε-LDP） -------------------------------
    def perturb(self, X):
        e = self.eps
        if self.mode == 'AP':
            self.q11 = np.exp(e) / (1.0 + np.exp(e))   # P(ỹ=1 | y=1)
            self.q10 = 1.0 / (1.0 + np.exp(e))         # P(ỹ=1 | y=0)
        else:  # SP 对称翻转
            self.q11 = np.exp(e) / (1.0 + np.exp(e))
            self.q10 = 1.0 - self.q11
        # 上报值 = Bernoulli(P(ỹ=1|y))
        p_report = self.q11 * X + self.q10 * (1.0 - X)
        return (np.random.rand(*X.shape) < p_report).astype(np.float32)

    # ---- 步骤 2：服务器端无偏估计 + 相似度矩阵 --------------------------
    def fit(self, df_train):
        X = build_user_profiles(df_train, self.num_users, self.num_items)
        Xt = self.perturb(X)
        n = Xt.shape[0]
        q11, q10 = self.q11, self.q10
        d = q11 - q10
        # 边缘概率无偏估计
        freq1 = Xt.mean(axis=0)
        p_hat = np.clip((freq1 - q10) / d, 0.0, 1.0)
        # 联合概率无偏估计: E[ỹ_i ỹ_j] = p_ij d^2 + (p_i+p_j) q10 d + q10^2
        M = (Xt.T @ Xt) / n
        M[np.diag_indices_from(M)] = p_hat  # 对角线用边缘估计
        cross = M - q10 ** 2 - (p_hat[:, None] + p_hat[None, :]) * q10 * d
        p_ij = np.clip(cross / (d * d), 0.0, 1.0)
        p_ij = np.minimum(p_ij, np.minimum(p_hat[:, None], p_hat[None, :]))
        # 余弦相似度；对角线保留自相似度 1（标准物品级 CF：前缀中
        # 已出现的物品按重复消费信号计分）
        denom = np.sqrt(p_hat)[:, None] * np.sqrt(p_hat)[None, :]
        S = np.divide(p_ij, denom, out=np.zeros_like(p_ij), where=denom > 0)
        np.fill_diagonal(S, 1.0)
        # 仅保留每行 top-K 邻居（原文 KNN 邻域）
        if self.topk and self.topk < self.num_items:
            kth = np.sort(S, axis=1)[:, -self.topk][:, None]
            S[S < kth] = 0.0
        self.sim = S.astype(np.float32)
        return self

    # ---- 步骤 3：本地推理（前缀物品查询） -------------------------------
    def cumsum_scores(self, seq):
        return cumulative_cf_scores(seq, self.sim, self.num_items)

    def evaluate(self, df_test, ks=(10, 20)):
        return enumerate_pairs(
            df_test, lambda row: self.cumsum_scores(list(row['items'])),
            self.num_items, ks)
