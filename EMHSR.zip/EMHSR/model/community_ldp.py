# -*- coding: utf-8 -*-
"""社区级 LDP 社交推荐复现（Guo et al., "Community-based social
recommendation under local differential privacy protection",
Information Sciences 2023, 639: 119002）。

原文机制（无官方代码，按论文摘要描述复现）：
  1. 用户在给定区间内扰动自身度数（LDP），服务器据此发现粗粒度社区；
  2. 依据社区内/社区间关系特征生成细粒度社交图；
  3. 在生成的社交图上做社交推荐。

复现实现：
  * 社交通道（ε_soc = ε/2）：每条社交边随机响应（对称 GRR，P 保持 =
    e^{ε_soc}/(1+e^{ε_soc})）→ 扰动社交图；度数信息即含于该图。
    在扰动图上运行标签传播得到粗粒度社区；
  * 细粒度社交图：同社区内、且交互画像 Jaccard 相似度 ≥ 阈值的用户对
    建边（社区内/间关系特征）；
  * 交互动通道（ε_int = ε/2）：交互画像对称 GRR 位翻转（ε_int-LDP），
    服务器无偏反解后估计物品余弦相似度（物品级 CF）；
  * 打分：score = (1-α)·CF 打分 + α·社交邻居打分（邻居扰动画像均值）。

隐私预算组成：ε_soc + ε_int = ε（顺序组合）。
"""
import numpy as np

from .common import build_user_profiles, cumulative_cf_scores, enumerate_pairs


class CommunityLDPSocialRec:
    def __init__(self, epsilon, num_users, num_items, n_communities=10,
                 lp_iters=20, jaccard_thr=0.05, alpha=0.3, topk_neighbors=200,
                 seed=42):
        self.eps = float(epsilon)
        self.eps_soc = self.eps / 2.0
        self.eps_int = self.eps / 2.0
        self.num_users = num_users
        self.num_items = num_items
        self.n_communities = n_communities
        self.lp_iters = lp_iters
        self.jaccard_thr = jaccard_thr
        self.alpha = alpha
        self.topk = topk_neighbors
        self.seed = seed

    # ---- GRR 位翻转（对称） --------------------------------------------
    def _grr_flip(self, X, eps):
        p = np.exp(eps) / (1.0 + np.exp(eps))
        # 上报值 = Bernoulli(P(ỹ=1|y))：y=1 保持 w.p. p，y=0 翻转为 1 w.p. 1-p
        p_report = p * X + (1.0 - p) * (1.0 - X)
        Xt = (np.random.rand(*X.shape) < p_report).astype(np.float32)
        return Xt, p

    def _unbias(self, Xt, p):
        d = 2 * p - 1.0
        return np.clip((Xt - (1.0 - p)) / d, 0.0, 1.0)

    # ---- 标签传播社区发现 ----------------------------------------------
    def _label_propagation(self, adj, rng):
        n = adj.shape[0]
        labels = rng.permutation(n) % self.n_communities
        adj_sym = np.maximum(adj, adj.T)
        for _ in range(self.lp_iters):
            new = labels.copy()
            for u in range(n):
                nb = np.where(adj_sym[u] > 0)[0]
                if len(nb) == 0:
                    continue
                counts = np.bincount(labels[nb], minlength=self.n_communities)
                new[u] = int(np.argmax(counts))
            if np.array_equal(new, labels):
                break
            labels = new
        return labels

    # ------------------------------------------------------------------
    def fit(self, df_train, social_edges):
        rng = np.random.RandomState(self.seed)
        # 1) 社交图随机响应扰动 → 粗粒度社区
        n = self.num_users
        adj_true = np.zeros((n, n), dtype=np.float32)
        for f, t in social_edges:
            if f < n and t < n:
                adj_true[f, t] = 1.0
                adj_true[t, f] = 1.0
        adj_noisy, p_soc = self._grr_flip(adj_true, self.eps_soc)
        adj_rel = self._unbias(adj_noisy, p_soc)
        adj_bin = (adj_noisy > 0.5).astype(np.float32)
        self.communities = self._label_propagation(adj_bin, rng)

        # 2) 细粒度社交图：同社区 + 交互画像相似
        X = build_user_profiles(df_train, n, self.num_items)
        Xn = X / (np.linalg.norm(X, axis=1, keepdims=True) + 1e-12)
        inter = Xn @ Xn.T
        np.fill_diagonal(inter, 0.0)
        fine = np.zeros((n, n), dtype=np.float32)
        same = self.communities[:, None] == self.communities[None, :]
        fine[(same) & (inter >= self.jaccard_thr)] = 1.0
        self.social_fine = fine

        # 3) 交互画像扰动（ε_int）→ 无偏估计 → 物品相似度
        Xt, p_int = self._grr_flip(X, self.eps_int)
        Xhat = self._unbias(Xt, p_int)
        freq1 = Xhat.mean(axis=0)
        M = (Xhat.T @ Xhat) / n
        M[np.diag_indices_from(M)] = freq1
        sim = np.divide(
            M, np.sqrt(freq1)[:, None] * np.sqrt(freq1)[None, :],
            out=np.zeros_like(M), where=freq1[:, None] * freq1[None, :] > 0)
        np.fill_diagonal(sim, 1.0)  # 自相似度（重复消费信号）
        if self.topk < self.num_items:
            kth = np.sort(sim, axis=1)[:, -self.topk][:, None]
            sim[sim < kth] = 0.0
        self.sim = sim.astype(np.float32)

        # 4) 社交邻居打分（服务器仅见细粒度社交图 + 扰动画像）
        deg = fine.sum(1, keepdims=True)
        social_scores = (fine @ Xhat) / np.maximum(deg, 1.0)
        self.social_scores = social_scores.astype(np.float32)
        return self

    # ------------------------------------------------------------------
    def evaluate(self, df_test, ks=(10, 20)):
        a = self.alpha

        def score_fn(row):
            u = int(row['userId'])
            cf = cumulative_cf_scores(list(row['items']), self.sim,
                                      self.num_items)
            return (1 - a) * cf + a * self.social_scores[u]

        return enumerate_pairs(df_test, score_fn, self.num_items, ks)
