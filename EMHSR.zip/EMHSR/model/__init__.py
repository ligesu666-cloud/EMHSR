# -*- coding: utf-8 -*-
"""表10 隐私保护基线的复现模型（协议适配版）。

四个基线均为独立论文提出的方法，官方代码不可用（DPLCF / Improved DP-CF /
社区级 LDP 无公开代码；LPGNN 官方代码仅支持节点分类任务），
故按各论文描述的隐私机制做机制级复现，并适配到本稿统一的
会话推荐协议（7:1:2 时间划分、全物品排序、HR@20、ε=0.1）。

  * dplcf.py          — DPLCF（Gao et al., SIGIR 2020）：随机位翻转 LDP +
                        无偏相似度估计 + 物品级协同过滤。
  * improved_dpcf.py  — Improved DP-CF（Yin et al., J. Supercomputing 2020）：
                        DiffGen 式 ε-DP 决策树合成数据发布 + 时间因子加权 CF。
  * lpgnn_rec.py      — LPGNN（Sajadmanesh & Gatica-Perez, CCS 2021）：
                        官方 1-bit 机制（1BM）扰动 + KProp 去噪 + GCN 打分。
  * community_ldp.py  — 社区级 LDP 社交推荐（Guo et al., Inf. Sci. 2023）：
                        扰动社交图 → 粗粒度社区 → 细粒度社交图 → 社交增强 CF。
"""
