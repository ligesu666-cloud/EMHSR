from collections import defaultdict
import logging
import time

import pandas as pd
import torch as th
from torch import nn,optim
from Utils.util import *


class TrainRunner:
    def __init__(
        self,
        train_loader,
        valid_loader,
        test_loader,
        prepare_batch,
        model,

        Ks=[20],
        lr=1e-3,
        weight_decay=0,
        ignore_list=None,
        patience=2,
        OTF=False,
        **kwargs,
    ):
        self.model = model
        if weight_decay > 0:
            if ignore_list is not None:
                params = fix_weight_decay(model, ignore_list)
            else:
                params = model.parameters()
        self.optimizer = optim.AdamW(params, lr=lr, weight_decay=weight_decay)
        self.criterion = nn.CrossEntropyLoss()
        self.train_loader = train_loader
        self.valid_loader = valid_loader
        self.test_loader = test_loader
        self.prepare_batch = prepare_batch
        self.Ks = Ks
        self.epoch = 0
        self.batch = 0
        self.patience = patience if patience > 0 else 2
        self.precompute = hasattr(model, 'KGE_layer') and not OTF

    def train(self, epochs, log_interval=100):
        best_results = defaultdict(float)
        report_results = defaultdict(float)
        bad_counter = 0
        t = time.time()
        mean_loss = 0
        final_result=pd.DataFrame()
        batch_time={}
        for epoch in range(epochs):
            self.model.train()
            train_ts = time.time()
            for batch in self.train_loader:
                inputs, labels = self.prepare_batch(batch)
                self.optimizer.zero_grad()
                logits = self.model(*inputs)
                loss = self.criterion(logits, labels)
                loss.backward()
                self.optimizer.step()
                mean_loss += loss.item() / log_interval
                if self.batch > 0 and self.batch % log_interval == 0:
                    logging.info(
                        f'Batch {self.batch}: Loss = {mean_loss:.4f}, Elapsed Time = {time.time() - t:.2f}s'
                    )
                    batch_time[f'Batch{self.batch}:Loss']=f'{mean_loss:.4f}'
                    batch_time[f'Batch{self.batch}:Elapsed Time']=f'{time.time() - t:.2f}s'
                    t = time.time()
                    mean_loss = 0
                self.batch += 1
            eval_ts = time.time()
            logging.debug(
                f'Training time per {log_interval} batches: '
                f'{(eval_ts - train_ts) / len(self.train_loader) * log_interval:.2f}s'
            )
            batch_time[f'Training time per {log_interval} batches: ']=f'{(eval_ts - train_ts) / len(self.train_loader) * log_interval:.2f}s'
            if self.precompute:
                ts = time.time()
                self.model.precompute_KG_embeddings()
                te = time.time()
                logging.debug(f'Precomuting KG embeddings took {te - ts:.2f}s')

            ts = time.time()
            valid_results = evaluate(
                self.model, self.valid_loader, self.prepare_batch, self.Ks
            )
            test_results = evaluate(
                self.model, self.test_loader, self.prepare_batch, self.Ks
            )
            if self.precompute:
                # release precomputed KG embeddings
                self.model.KG_embeddings = None
                th.cuda.empty_cache()
            te = time.time()
            num_batches = len(self.valid_loader) + len(self.test_loader)
            logging.debug(
                f'Evaluation time per {log_interval} batches: '
                f'{(te - ts) / num_batches * log_interval:.2f}s'
            )
            batch_time[f'Evaluation time per {log_interval} batches: ']=f'{(te - ts) / num_batches * log_interval:.2f}s'

            logging.warning(f'Epoch {self.epoch}:')
            print_results(('Valid', valid_results), ('Test', test_results))

            val_df=dict2df(valid_results,f'Epoch_{epoch}_val')
            test_df=dict2df(test_results,f'Epoch_{epoch}_test')
            final_result=final_result.append(val_df)
            final_result=final_result.append(test_df)




            any_better_result = False
            for metric in valid_results:
                if valid_results[metric] > best_results[metric]:
                    best_results[metric] = valid_results[metric]
                    report_results[metric] = test_results[metric]
                    any_better_result = True

            if any_better_result:
                bad_counter = 0
            else:
                bad_counter += 1
                if bad_counter == self.patience:
                    break
            self.epoch += 1
            eval_te = time.time()
            t += eval_te - eval_ts
            report_df=dict2df(report_results,'report')
        final_result=final_result.append(report_df)

        print_results(('Report', report_results))
        return report_results,final_result,batch_time
