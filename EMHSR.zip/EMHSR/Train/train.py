import logging
import importlib
import os
import pandas as pd

from Train.ParserTrain import *
from Utils.paths import result_dir, finalresult_dir
import torch as th
from torch.utils.data import DataLoader
from srs.layers.seframe import SEFrame
from Utils.DataLoader.load import *
from Train.trainModel import *



class TrainRun():
    def __init__(self,args,dataset_name,model_name,edge_style):
        self.args=args
        self.dataset_name=dataset_name
        self.model_name=model_name
        self.edges_style=edge_style



    def GetLoader(self):
        self.args.model=self.model_name
        from Utils.paths import dataset_dir, dataset_dp_dir
        self.args.dataset_dir = dataset_dir(self.dataset_name)
        _dp_suffix = getattr(self.args, 'dp_suffix', '') or ''
        self.args.dataset_dp_dir = dataset_dp_dir(
            self.dataset_name, self.args.epsilon, _dp_suffix)
        # if self.args.model_args:
        #     self.args.model_args = eval(self.args.model_args)
        # else:
        #     self.args.model_args = {}
        self.args.model_args = eval(self.args.model_args)
        self.args.num_neighbors = [int(x) for x in self.args.num_neighbors.split(',')]
        self.args.Ks = [int(K) for K in self.args.Ks.split(',')]
        self.args.ignore_list = [x.strip() for x in self.args.ignore_list.split(',') if x.strip() != '']

        module = importlib.import_module(f'srs.models.{self.args.model}')
        config = module.config
        for k, v in vars( self.args).items():
            config[k] = v
        self.args = config
        print('args:',self.args)

        log_level = getattr(logging, self.args.log_level.upper(), None)
        logging.basicConfig(format='%(message)s', level=log_level)
        logging.debug(self.args)

        self.args.prepare_batch = self.args.prepare_batch_factory()
        logging.info(f'reading dataset {self.args.dataset_dir}...')
        df_train, df_valid, df_test, stats = read_dataset(self.args.dataset_dir)
        if exp_style=='dp':
            df_train,df_valid,df_test,_=read_dataset(self.args.dataset_dp_dir)


        if issubclass(self.args.Model, SEFrame):
            from Utils.paths import data_root
            social_network = read_social_network(self.dataset_name,self.edges_style,self.args.epsilon, data_root())
            self.args.knowledge_graph = build_knowledge_graph(
                df_train, social_network,
                use_pp=getattr(self.args, 'use_pp', True),
                num_users=getattr(stats, 'num_users', None),
                num_items=stats.num_items)

        elif self.args.Model.__name__ == 'DGRec':

            visible_time_list, in_neighbors = compute_visible_time_list_and_in_neighbors(
                df_train, self.args.dataset_dir, self.args.num_layers
            )
            self.args.visible_time_list = visible_time_list
            self.args.in_neighbors = in_neighbors
            self.args.uid2sessions = [{
                'sids': df['sessionId'].values,
                'sessions': df['items'].values
            } for _, df in df_train.groupby('userId')]
            L_hop_visible_time = visible_time_list[self.args.num_layers]

            df_train, df_valid, df_test = filter_invalid_sessions(
                df_train, df_valid, df_test, L_hop_visible_time=L_hop_visible_time
            )




        self.args.num_users = getattr(stats, 'num_users', None)
        self.args.num_items = stats.num_items
        self.args.max_len = stats.max_len

        model = self.args.Model(**self.args, **self.args.model_args)

        logging.debug(model)

        if self.args.num_users is None:
            train_set = AnonymousAugmentedDataset(df_train)
            valid_set = AnonymousAugmentedDataset(df_valid)
            test_set = AnonymousAugmentedDataset(df_test)
        else:
            read_sid = self.args.Model.__name__ == 'DGRec'
            train_set = AugmentedDataset(df_train, read_sid)
            valid_set = AugmentedDataset(df_valid, read_sid)
            test_set = AugmentedDataset(df_test, read_sid)

        if 'CollateFn' in self.args:
            collate_fn = self.args.CollateFn(**self.args)
            collate_train = collate_fn.collate_train
            if self.args.OTF and issubclass(self.args.Model, SEFrame):
                print('compute KG embeddings on the fly')
                collate_test = collate_fn.collate_test_otf
            else:
                collate_test = collate_fn.collate_test
        else:
            collate_train = collate_test = self.args.collate_fn

        self.args.model = model


        if 'BatchSampler' in config:
            logging.debug('using batch sampler')
            batch_sampler = config.BatchSampler(
                train_set, batch_size=self.args.batch_size, drop_last=True, seed=0
            )
            train_loader = DataLoader(
                train_set,
                batch_sampler=batch_sampler,
                collate_fn=collate_train,
                num_workers=self.args.num_workers,
            )
        else:
            train_loader = DataLoader(
                train_set,
                batch_size=self.args.batch_size,
                collate_fn=collate_train,
                num_workers=self.args.num_workers,
                drop_last=True,
                shuffle=True,
            )

        valid_loader = DataLoader(
            valid_set,
            batch_size=self.args.batch_size,
            collate_fn=collate_test,
            num_workers=self.args.num_workers,
            drop_last=False,
            shuffle=False,
        )

        test_loader = DataLoader(
            test_set,
            batch_size=self.args.batch_size,
            collate_fn=collate_test,
            num_workers=self.args.num_workers,
            drop_last=False,
            shuffle=False,
        )
        return self.args,train_loader,valid_loader,test_loader

if __name__=='__main__':
    # ----------------------------------------------------------------------
    # 运行方式说明
    #   * 非 DP 基线：exp_style='non_dp'，加载 raw/ 数据，edge_style='edges'。
    #   * EMHSR（论文提出的带噪模型）：exp_style='dp'，加载 dp_<epsilon>/ 数据，
    #     edge_style='sampling'（差分隐私边掩码后的社交边）。
    # 可通过环境变量覆盖：
    #   EMHSR_EXP=dp|non_dp    EMHSR_EPS=0.1    EMHSR_DATASET=gowalla
    # 例如：EMHSR_EXP=dp EMHSR_EPS=0.1 python Train/train.py --model EMHSR
    # ----------------------------------------------------------------------
    import os as _os
    exp_style = _os.environ.get('EMHSR_EXP', 'non_dp')
    dataset_name = _os.environ.get('EMHSR_DATASET', 'gowalla')
    if exp_style == 'dp':
        args0 = TrainParser()
        args0.epsilon = float(_os.environ.get('EMHSR_EPS', '0.1'))

    # 基线模型 + 论文提出的 EMHSR
    model_list = ['EMHSR', 'SSRGNN', 'SERec', 'SRGNN', 'SSRM', 'SSSRM',
                  'SNARM', 'SNextItNet', 'SSTAMP', 'STAMP', 'NextItNet']

    # 仅运行命令行指定的模型（默认全部）
    cli_model = _os.environ.get('EMHSR_MODEL')
    if cli_model:
        model_list = [cli_model]

    for model_name in model_list:
        args = TrainParser()
        if exp_style == 'dp':
            args.epsilon = float(_os.environ.get('EMHSR_EPS', '0.1'))
        # EMHSR 与非 DP 模式：DP 实验使用加噪社交边（sampling），其余用原始边
        edges_style = 'sampling' if (exp_style == 'dp' and model_name == 'EMHSR') else 'edges'
        style = f'dp_{args.epsilon}' if exp_style == 'dp' else 'non_dp'
        output_dir = f'{result_dir(dataset_name, style)}/'
        if not _os.path.exists(output_dir):
            _os.makedirs(output_dir)
        args, train_loader, valid_loader, test_loader = TrainRun(
            args, dataset_name, model_name, edges_style).GetLoader()
        prepare_batch = args.prepare_batch
        runner = TrainRunner(train_loader, valid_loader, test_loader, **args)
        results, final_result, batch_time = runner.train(args.epochs, log_interval=args.log_interval)
        final_result.to_excel(output_dir + f'{model_name}_{style}.xlsx')

        batch_time = pd.DataFrame(batch_time.items(), columns=['key', 'value'])
        time_dir = f'{result_dir(dataset_name, "runtime")}/'
        if not _os.path.exists(time_dir):
            _os.makedirs(time_dir)
        batch_time.to_excel(time_dir + f'{model_name}_{style}.xlsx', index=False)



