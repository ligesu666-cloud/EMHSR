import argparse
def TrainParser():
    parser=argparse.ArgumentParser()
    parser.add_argument(
        '--embedding_dim', type=int, default=128, help='the dimensionality of embeddings'
    )
    parser.add_argument(
        '--feat_drop', type=float, default=0.2, help='the dropout ratio for input features'
    )
    parser.add_argument(
        '--num_layers',
        type=int,
        default=1,
        help='the number of HGNN layers in the KGE component',
    )
    parser.add_argument(
        '--num_heads',
        type=int,
        default=1,
        help='the number of attention heads in the heterogeneous graph attention (HGAN)',
    )
    parser.add_argument(
        '--use-pse',
        dest='use_pse',
        action='store_true',
        default=True,
        help='enable the personalized session encoding layer (PSE, §4.4); '
             'pass --no-use-pse to ablate it',
    )
    parser.add_argument(
        '--no-use-pse',
        dest='use_pse',
        action='store_false',
        help='ablate PSE (w/o PSE)',
    )
    parser.add_argument(
        '--use-hgan',
        dest='use_hgan',
        action='store_true',
        default=True,
        help='enable the heterogeneous graph attention network (HGAN); '
             'pass --no-use-hgan to replace it with a vanilla mean aggregator',
    )
    parser.add_argument(
        '--no-use-hgan',
        dest='use_hgan',
        action='store_false',
        help='ablate HGAN (w/o HGAN): vanilla GNN aggregator',
    )
    parser.add_argument(
        '--use-pp',
        dest='use_pp',
        action='store_true',
        default=True,
        help='include item–item (PP) transition edges in the knowledge graph; '
             'pass --no-use-pp to ablate them (w/o PP mask)',
    )
    parser.add_argument(
        '--no-use-pp',
        dest='use_pp',
        action='store_false',
        help='ablate PP (w/o PP mask): drop item–item transition edges',
    )
    parser.add_argument(
        '--dp-suffix',
        type=str,
        default='',
        help='suffix for the dp data directory, e.g. "_wo_uu" for ablation',
    )
    parser.add_argument(
        '--num_neighbors',
        default='10',
        help='the number of neighbors to sample at each layer.'
             ' Give an integer if the number is the same for all layers.'
             ' Give a list of integers separated by commas if this number is different at different layers, e.g., 10,10,5'
    )
    parser.add_argument('--batch-size', type=int, default=128, help='the batch size')
    parser.add_argument(
        '--epochs', type=int, default=30, help='the maximum number of training epochs'
    )
    parser.add_argument('--lr', type=float, default=1e-3, help='the learning rate')
    parser.add_argument(
        '--weight_decay',
        type=float,
        default=1e-4,
        help='the weight decay for the optimizer',
    )
    parser.add_argument(
        '--patience',
        type=int,
        default=2,
        help='stop training if the performance does not improve in this number of consecutive epochs',
    )
    parser.add_argument(
        '--Ks',
        default='10,20',
        help='the values of K in evaluation metrics, separated by commas'
    )
    parser.add_argument(
        '--ignore_list',
        default='bias,batch_norm,activation',
        help='the names of parameters excluded from being regularized',
    )
    parser.add_argument(
        '--log_level',
        choices=['debug', 'info', 'warning', 'error'],
        default='debug',
        help='the log level',
    )
    parser.add_argument(
        '--log_interval',
        type=int,
        default=1000,
        help='if log level is info or debug, print training information after every this number of iterations',
    )
    parser.add_argument(
        '--num_workers',
        type=int,
        default=0,
        help='the number of processes for data loaders',
    )

    parser.add_argument(
        '--model-args',
        type=str,
        default="{}",
        help="the extra arguments passed to the model's initializer."
             ' Will be evaluated as a dictionary.',
    )

    parser.add_argument(
        "--model",
        type=str,
        help="the prediction model"
    )

    parser.add_argument(
        "--dataset_dir",
        type=str,
        help="the dataset set directory"
    )
    parser.add_argument(
        '--OTF',
        action='store_true',
        help='compute KG embeddings on the fly instead of precomputing them before inference to save memory',
    )
    parser.add_argument("--p",
                        type=float,
                        default=1,
                        help="the noise budget")
    parser.add_argument("--sensitivity",
                        type=float,
                        default=1,
                        help='sensitivity')
    parser.add_argument("--epsilon",
                        type=float,
                        default=0.5,
                        help="epsilon")

    return parser.parse_args()